import { useCallback } from 'react';
import { supabase } from '../lib/supabase';
import type { GameState } from '../game/types';

export function useSave(sessionId: string) {
  const save = useCallback(async (state: GameState, slot = 1) => {
    const saveData = {
      screen: state.screen,
      party: state.party,
      activeCharacterId: state.activeCharacterId,
      unlockedCharacters: state.unlockedCharacters,
      storyFlags: state.storyFlags,
      explorationState: state.explorationState,
      difficulty: state.difficulty,
    };
    await supabase.from('save_games').upsert(
      { session_id: sessionId, slot_number: slot, save_data: saveData, updated_at: new Date().toISOString() },
      { onConflict: 'session_id,slot_number' }
    );
  }, [sessionId]);

  const load = useCallback(async (slot = 1): Promise<Partial<GameState> | null> => {
    const { data } = await supabase
      .from('save_games')
      .select('save_data')
      .eq('session_id', sessionId)
      .eq('slot_number', slot)
      .maybeSingle();
    return data?.save_data ?? null;
  }, [sessionId]);

  const listSaves = useCallback(async () => {
    const { data } = await supabase
      .from('save_games')
      .select('slot_number, updated_at, save_data')
      .eq('session_id', sessionId)
      .order('slot_number');
    return data ?? [];
  }, [sessionId]);

  return { save, load, listSaves };
}
