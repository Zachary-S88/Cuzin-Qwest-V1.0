import { useEffect, useCallback } from 'react';

let tapCount = 0;
let tapTimer: ReturnType<typeof setTimeout> | null = null;
let keyBuffer = '';
let keyTimer: ReturnType<typeof setTimeout> | null = null;

export function useDevMenu(onOpen: () => void) {
  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (e.key === 'c' || e.key === 'C') {
        keyBuffer += 'c';
        if (keyTimer) clearTimeout(keyTimer);
        keyTimer = setTimeout(() => { keyBuffer = ''; }, 600);
        if (keyBuffer === 'cc') {
          keyBuffer = '';
          onOpen();
        }
      } else {
        keyBuffer = '';
      }
    },
    [onOpen]
  );

  const handleTouch = useCallback(
    () => {
      tapCount++;
      if (tapTimer) clearTimeout(tapTimer);
      tapTimer = setTimeout(() => { tapCount = 0; }, 400);
      if (tapCount >= 2) {
        tapCount = 0;
        onOpen();
      }
    },
    [onOpen]
  );

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('touchend', handleTouch);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('touchend', handleTouch);
    };
  }, [handleKeyDown, handleTouch]);
}
