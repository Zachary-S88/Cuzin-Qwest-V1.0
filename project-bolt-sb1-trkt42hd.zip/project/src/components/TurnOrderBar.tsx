import React from 'react';
import type { CombatUnit } from '../game/types';

interface Props {
  turnOrder: string[];
  units: CombatUnit[];
  activeUnitId: string | null;
  turnCount: number;
}

export default function TurnOrderBar({ turnOrder, units, activeUnitId, turnCount }: Props) {
  const unitMap = new Map(units.map((u) => [u.unitId, u]));

  return (
    <div className="flex items-center gap-2 px-3 py-2 overflow-x-auto">
      <span className="text-xs text-gray-400 font-bold shrink-0">TURN {turnCount + 1}</span>
      <div className="w-px h-4 bg-gray-600 shrink-0" />
      {turnOrder.map((id) => {
        const unit = unitMap.get(id);
        if (!unit) return null;
        const isActive = id === activeUnitId;
        const isDead = unit.currentHp <= 0;
        return (
          <div
            key={id}
            className={`flex flex-col items-center gap-0.5 shrink-0 transition-all duration-200 ${
              isActive ? 'scale-125' : isDead ? 'opacity-30 grayscale' : 'opacity-60 hover:opacity-80'
            }`}
          >
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-black border-2 ${
                isActive ? 'border-yellow-400 shadow-lg shadow-yellow-400/30' : 'border-transparent'
              }`}
              style={{ backgroundColor: unit.color }}
            >
              {unit.emoji}
            </div>
            <span className="text-white font-bold" style={{ fontSize: 8 }}>
              {unit.name.slice(0, 4)}
            </span>
            {isActive && (
              <div className="w-1.5 h-1.5 rounded-full bg-yellow-400 animate-pulse" />
            )}
          </div>
        );
      })}
    </div>
  );
}
