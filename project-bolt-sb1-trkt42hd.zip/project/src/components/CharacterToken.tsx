import React from 'react';
import type { CharacterId, EnemyId } from '../game/types';

interface Props {
  sourceId: CharacterId | EnemyId;
  name: string;
  color: string;
  emoji: string;
  currentHp: number;
  maxHp: number;
  isActive?: boolean;
  isDead?: boolean;
  isEnemy?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export default function CharacterToken({
  name, color, emoji, currentHp, maxHp, isActive, isDead, size = 'md',
}: Props) {
  const hpPct = Math.max(0, (currentHp / maxHp) * 100);
  const hpColor = hpPct > 60 ? '#22c55e' : hpPct > 25 ? '#f59e0b' : '#ef4444';

  const sizes = {
    sm: { outer: 32, font: 14 },
    md: { outer: 44, font: 18 },
    lg: { outer: 56, font: 22 },
  };
  const s = sizes[size];

  return (
    <div
      className={`relative flex flex-col items-center transition-all duration-300 ${isDead ? 'opacity-30 grayscale' : ''} ${isActive ? 'scale-110 drop-shadow-lg' : ''}`}
      style={{ width: s.outer + 8 }}
    >
      {/* Active indicator ring */}
      {isActive && (
        <div
          className="absolute inset-0 rounded-full animate-pulse"
          style={{ border: `3px solid ${color}`, borderRadius: '50%', width: s.outer + 8, height: s.outer + 8, top: -4, left: 0 }}
        />
      )}
      {/* HP bar */}
      <div className="w-full h-1.5 bg-gray-700 rounded-full mb-1 overflow-hidden" style={{ width: s.outer }}>
        <div
          className="h-full rounded-full transition-all duration-300"
          style={{ width: `${hpPct}%`, backgroundColor: hpColor }}
        />
      </div>
      {/* Token circle */}
      <div
        className="rounded-full flex items-center justify-center font-black border-2 border-white/20 shadow-lg"
        style={{
          width: s.outer,
          height: s.outer,
          backgroundColor: color,
          fontSize: s.font,
          opacity: isDead ? 0.4 : 1,
        }}
      >
        <span style={{ filter: 'drop-shadow(0 1px 2px rgba(0,0,0,0.5))' }}>{emoji}</span>
      </div>
      {/* Name */}
      <span
        className="mt-0.5 text-center font-bold text-white leading-none truncate"
        style={{ fontSize: 9, maxWidth: s.outer + 8 }}
      >
        {name}
      </span>
    </div>
  );
}
