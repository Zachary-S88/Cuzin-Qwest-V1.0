import React, { useState } from 'react';
import { useGame } from '../contexts/GameContext';
import { CHARACTERS } from '../game/characters';
import type { CharacterId, Difficulty } from '../game/types';
import { X } from 'lucide-react';

interface Props {
  onClose: () => void;
}

const ALL_CHARACTERS: CharacterId[] = ['zachy', 'davy', 'granty', 'whyWhy', 'meggie'];

export default function DevMenu({ onClose }: Props) {
  const { state, dispatch } = useGame();
  const [log, setLog] = useState('Dev menu open.');

  function logAction(msg: string) {
    setLog(msg);
  }

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[9999] p-4">
      <div className="bg-gray-900 border border-yellow-500 rounded-2xl w-full max-w-sm shadow-2xl shadow-yellow-500/20 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-yellow-500/10 border-b border-yellow-500/30">
          <div>
            <div className="text-yellow-400 font-black text-lg">🔧 DEV MENU</div>
            <div className="text-yellow-600 text-xs font-mono">SUPER SECRET — CUZIN QWEST</div>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-white/10 rounded-lg transition-all">
            <X size={18} className="text-gray-400" />
          </button>
        </div>

        <div className="p-4 space-y-3 overflow-y-auto max-h-[70vh]">
          {/* Log */}
          <div className="bg-black/50 rounded-lg px-3 py-2 font-mono text-xs text-green-400 border border-green-900">
            &gt; {log}
          </div>

          {/* Difficulty */}
          <div>
            <div className="text-gray-400 text-xs font-bold uppercase mb-1">Difficulty</div>
            <div className="grid grid-cols-3 gap-1">
              {(['easy', 'normal', 'hard'] as Difficulty[]).map((d) => (
                <button
                  key={d}
                  onClick={() => { dispatch({ type: 'SET_DIFFICULTY', difficulty: d }); logAction(`Difficulty set to ${d}.`); }}
                  className={`py-1.5 rounded-lg text-xs font-bold capitalize transition-all active:scale-95 ${state.difficulty === d ? 'bg-yellow-500 text-gray-900' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'}`}
                >
                  {d}
                </button>
              ))}
            </div>
          </div>

          {/* Unlock Characters */}
          <div>
            <div className="text-gray-400 text-xs font-bold uppercase mb-1">Unlock Characters</div>
            <div className="space-y-1">
              {ALL_CHARACTERS.map((id) => {
                const def = CHARACTERS[id];
                const unlocked = state.unlockedCharacters.includes(id);
                return (
                  <div key={id} className="flex items-center gap-2 bg-gray-800 rounded-lg px-3 py-2">
                    <span className="text-lg">{def.emoji}</span>
                    <span className="text-white text-sm font-bold flex-1">{def.name}</span>
                    <span className={`text-xs px-2 py-0.5 rounded ${unlocked ? 'bg-green-800 text-green-300' : 'bg-gray-700 text-gray-400'}`}>
                      {unlocked ? 'Unlocked' : 'Locked'}
                    </span>
                    {!unlocked && (
                      <button
                        onClick={() => { dispatch({ type: 'UNLOCK_CHARACTER', characterId: id }); logAction(`Unlocked ${def.name}!`); }}
                        className="px-2 py-0.5 bg-yellow-600 hover:bg-yellow-500 text-xs text-white rounded font-bold transition-all active:scale-95"
                      >
                        Unlock
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Level Up Boosts */}
          <div>
            <div className="text-gray-400 text-xs font-bold uppercase mb-1">Power Boost (Party)</div>
            {state.party.map((pm) => {
              const def = CHARACTERS[pm.characterId];
              return (
                <div key={pm.characterId} className="flex items-center gap-2 bg-gray-800 rounded-lg px-3 py-2 mb-1">
                  <span>{def.emoji}</span>
                  <span className="text-white text-sm flex-1">{def.name} Lv.{pm.level}</span>
                  <button
                    onClick={() => {
                      dispatch({ type: 'LEVEL_UP_BOOST', characterId: pm.characterId, statKey: 'attack' });
                      logAction(`Boosted ${def.name}'s Attack!`);
                    }}
                    className="px-2 py-0.5 bg-red-700 hover:bg-red-600 text-xs text-white rounded font-bold transition-all active:scale-95"
                  >
                    +ATK
                  </button>
                  <button
                    onClick={() => {
                      dispatch({ type: 'LEVEL_UP_BOOST', characterId: pm.characterId, statKey: 'maxHp' });
                      logAction(`Boosted ${def.name}'s HP!`);
                    }}
                    className="px-2 py-0.5 bg-green-700 hover:bg-green-600 text-xs text-white rounded font-bold transition-all active:scale-95"
                  >
                    +HP
                  </button>
                </div>
              );
            })}
          </div>

          {/* Navigation Shortcuts */}
          <div>
            <div className="text-gray-400 text-xs font-bold uppercase mb-1">Navigate</div>
            <div className="grid grid-cols-3 gap-1">
              {(['title', 'opening', 'hub', 'exploration', 'bossChoice', 'gameOver'] as const).map((s) => (
                <button
                  key={s}
                  onClick={() => { dispatch({ type: 'NAVIGATE', screen: s }); logAction(`Navigated to ${s}.`); onClose(); }}
                  className="py-1.5 rounded-lg text-xs font-bold bg-gray-700 hover:bg-gray-600 text-gray-300 capitalize transition-all active:scale-95"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* Boss Fight Shortcut */}
          <button
            onClick={() => {
              dispatch({ type: 'START_COMBAT', enemyIds: ['shelly', 'kevin'], enemyLevels: [5, 5], environment: 'fortress', isBoss: true });
              logAction('Started boss fight!');
              onClose();
            }}
            className="w-full py-2 rounded-lg text-sm font-bold bg-red-700 hover:bg-red-600 text-white transition-all active:scale-95"
          >
            ⚡ Start Boss Fight (Shelly & Kevin)
          </button>

          <button
            onClick={() => {
              dispatch({ type: 'START_COMBAT', enemyIds: ['aquaGloop', 'lakeLurker'], enemyLevels: [2, 2], environment: 'lake', isBoss: false });
              logAction('Started test combat!');
              onClose();
            }}
            className="w-full py-2 rounded-lg text-sm font-bold bg-blue-700 hover:bg-blue-600 text-white transition-all active:scale-95"
          >
            🌊 Test Lake Combat
          </button>
        </div>
      </div>
    </div>
  );
}
