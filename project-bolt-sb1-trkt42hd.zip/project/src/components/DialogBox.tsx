import React, { useState, useEffect, useCallback } from 'react';

interface DialogLine {
  speaker?: string;
  text: string;
  portrait?: string; // emoji
  color?: string;
}

interface Props {
  lines: DialogLine[];
  onComplete: () => void;
  autoAdvanceMs?: number;
  onLineChange?: (index: number) => void;
}

export default function DialogBox({ lines, onComplete, autoAdvanceMs, onLineChange }: Props) {
  const [index, setIndex] = useState(0);
  const [displayed, setDisplayed] = useState('');
  const [isTyping, setIsTyping] = useState(true);

  const currentLine = lines[index];

  useEffect(() => {
    setDisplayed('');
    setIsTyping(true);
    let i = 0;
    const text = currentLine.text;
    const interval = setInterval(() => {
      i++;
      setDisplayed(text.slice(0, i));
      if (i >= text.length) {
        clearInterval(interval);
        setIsTyping(false);
      }
    }, 25);
    return () => clearInterval(interval);
  }, [index, currentLine.text]);

  const advance = useCallback(() => {
    if (isTyping) {
      setDisplayed(currentLine.text);
      setIsTyping(false);
      return;
    }
    if (index < lines.length - 1) {
      setIndex((i) => i + 1);
    } else {
      onComplete();
    }
  }, [isTyping, currentLine.text, index, lines.length, onComplete]);

  useEffect(() => {
    onLineChange?.(index);
  }, [index, onLineChange]);

  useEffect(() => {
    if (!isTyping && autoAdvanceMs) {
      const t = setTimeout(advance, autoAdvanceMs);
      return () => clearTimeout(t);
    }
  }, [isTyping, autoAdvanceMs, advance]);

  return (
    <div
      className="fixed bottom-0 left-0 right-0 z-50 p-3 cursor-pointer select-none"
      onClick={advance}
    >
      <div className="max-w-2xl mx-auto bg-gray-900/95 backdrop-blur-sm border border-gray-700 rounded-2xl p-4 shadow-2xl">
        {/* Speaker + portrait */}
        {currentLine.speaker && (
          <div className="flex items-center gap-2 mb-2">
            {currentLine.portrait && (
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center text-2xl"
                style={{ backgroundColor: currentLine.color ? `${currentLine.color}33` : '#1f2937', border: `2px solid ${currentLine.color ?? '#4b5563'}` }}
              >
                {currentLine.portrait}
              </div>
            )}
            <span className="font-black text-sm" style={{ color: currentLine.color ?? '#60a5fa' }}>
              {currentLine.speaker}
            </span>
          </div>
        )}
        {/* Text */}
        <p className="text-white text-sm leading-relaxed min-h-[3rem]">
          {displayed}
          {isTyping && <span className="animate-pulse text-blue-400">|</span>}
        </p>
        {/* Advance hint */}
        {!isTyping && (
          <div className="flex justify-end mt-2">
            <span className="text-gray-500 text-xs animate-bounce">
              {index < lines.length - 1 ? 'Tap to continue ▼' : 'Tap to finish ▼'}
            </span>
          </div>
        )}
      </div>
      {/* Progress dots */}
      <div className="flex justify-center gap-1 mt-2">
        {lines.map((_, i) => (
          <div
            key={i}
            className={`h-1 rounded-full transition-all duration-300 ${i === index ? 'w-4 bg-blue-400' : i < index ? 'w-2 bg-gray-600' : 'w-2 bg-gray-700'}`}
          />
        ))}
      </div>
    </div>
  );
}
