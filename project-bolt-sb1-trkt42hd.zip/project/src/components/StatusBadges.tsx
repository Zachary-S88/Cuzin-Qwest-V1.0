import React from 'react';
import type { ActiveStatusEffect, CombatBuff } from '../game/types';
import { STATUS_EFFECTS } from '../game/statusEffects';

interface Props {
  effects: ActiveStatusEffect[];
  buffs: CombatBuff[];
}

export default function StatusBadges({ effects, buffs }: Props) {
  if (effects.length === 0 && buffs.length === 0) return null;

  return (
    <div className="flex flex-wrap gap-0.5 justify-center mt-0.5">
      {buffs.map((buff) => (
        <div
          key={buff.id}
          title={`${buff.name}: ${buff.description}`}
          className="w-3 h-3 rounded-sm cursor-help border border-white/20"
          style={{ backgroundColor: buff.color }}
        />
      ))}
      {effects.map((e) => {
        const def = STATUS_EFFECTS[e.id];
        return (
          <div
            key={e.id}
            title={`${def.name}${e.turnsRemaining !== null ? ` (${e.turnsRemaining}t)` : ''}: ${def.description}`}
            className="w-3 h-3 rounded-full cursor-help border border-white/30 flex items-center justify-center"
            style={{ backgroundColor: def.bgColor, borderColor: def.color }}
          >
            <span style={{ fontSize: 6 }}>{def.emoji}</span>
          </div>
        );
      })}
    </div>
  );
}

interface TooltipBadgeProps {
  effect: ActiveStatusEffect;
}

export function StatusTooltipBadge({ effect }: TooltipBadgeProps) {
  const def = STATUS_EFFECTS[effect.id];
  return (
    <div className="flex items-center gap-2 p-2 rounded-lg text-sm" style={{ backgroundColor: def.bgColor }}>
      <span className="text-lg">{def.emoji}</span>
      <div>
        <div className="font-bold" style={{ color: def.color }}>{def.name}</div>
        <div className="text-xs text-gray-300">{def.description}</div>
        {effect.turnsRemaining !== null && (
          <div className="text-xs text-gray-400">{effect.turnsRemaining} turns remaining</div>
        )}
      </div>
    </div>
  );
}
