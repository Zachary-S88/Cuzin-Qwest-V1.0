import React from 'react';
import type { DamageNumber } from '../game/types';

interface Props {
  numbers: DamageNumber[];
  tileSize: number;
}

export default function FloatingDamage({ numbers, tileSize }: Props) {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden" style={{ zIndex: 50 }}>
      {numbers.map((n) => (
        <FloatItem key={n.id} item={n} tileSize={tileSize} />
      ))}
    </div>
  );
}

function FloatItem({ item, tileSize }: { item: DamageNumber; tileSize: number }) {
  const colors: Record<string, string> = {
    damage: '#ef4444',
    heal: '#22c55e',
    miss: '#94a3b8',
    critical: '#f59e0b',
    status: '#a855f7',
  };

  const left = item.x * tileSize + tileSize / 2;
  const top = item.y * tileSize;

  return (
    <div
      className="absolute font-black text-shadow pointer-events-none animate-float-damage select-none"
      style={{
        left,
        top,
        color: colors[item.type] ?? '#fff',
        fontSize: item.type === 'critical' ? 20 : 15,
        transform: 'translateX(-50%)',
        textShadow: '0 1px 4px rgba(0,0,0,0.8), 0 0 8px rgba(0,0,0,0.5)',
        whiteSpace: 'nowrap',
      }}
    >
      {item.value}
    </div>
  );
}
