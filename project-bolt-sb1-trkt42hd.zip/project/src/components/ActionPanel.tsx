import React, { useState } from 'react';
import type { CombatUnit, StatusEffectId } from '../game/types';
import { useGame } from '../contexts/GameContext';
import { STATUS_EFFECTS } from '../game/statusEffects';
import { CHARACTERS } from '../game/characters';
import { hasStatus } from '../game/statusEffects';

interface Props {
  activeUnit: CombatUnit;
  isMeggieNeedsDemeanor?: boolean;
}

type Panel = 'main' | 'special' | 'ability' | 'zachyOrb' | 'meggieDemereanor';

export default function ActionPanel({ activeUnit, isMeggieNeedsDemeanor }: Props) {
  const { state, dispatch } = useGame();
  const cs = state.combatState!;
  const [panel, setPanel] = useState<Panel>('main');
  const [zachyTargets, setZachyTargets] = useState<string[]>([]);
  const [zachyStatus, setZachyStatus] = useState<StatusEffectId>('poisoned');

  const { actionsUsed } = activeUnit;
  const isConfused = hasStatus(activeUnit, 'confused');
  const isIntimidated = hasStatus(activeUnit, 'intimidated');
  const canAttack = !actionsUsed.attacked && !hasStatus(activeUnit, 'occupied');
  const canAbility = !actionsUsed.ability && !isConfused && !isIntimidated;

  function btnClass(disabled: boolean) {
    return `px-3 py-2 rounded-lg font-bold text-sm transition-all duration-150 active:scale-95 ${
      disabled
        ? 'bg-gray-700 text-gray-500 cursor-not-allowed opacity-50'
        : 'bg-blue-600 hover:bg-blue-500 text-white shadow-md active:shadow-sm cursor-pointer'
    }`;
  }

  function selectAction(a: 'move' | 'attack' | 'ability' | 'special' | 'none') {
    dispatch({ type: 'COMBAT_SELECT_ACTION', action: a });
  }

  if (isMeggieNeedsDemeanor && activeUnit.demeanor === undefined) {
    return (
      <div className="p-3 bg-gray-900 border-t border-gray-700">
        <p className="text-yellow-400 font-bold text-sm mb-2">Choose Meggie's Demeanor:</p>
        <div className="grid grid-cols-2 gap-2">
          {(['silly', 'intimidating', 'tough', 'studious'] as const).map((d) => (
            <button
              key={d}
              onClick={() => dispatch({ type: 'SELECT_MEGGIE_DEMEANOR', demeanor: d })}
              className="p-2 rounded-lg bg-orange-700 hover:bg-orange-600 text-white font-bold text-sm capitalize transition-all active:scale-95"
            >
              {d}
            </button>
          ))}
        </div>
      </div>
    );
  }

  if (panel === 'zachyOrb') {
    const enemies = cs.units.filter((u) => !u.isPlayer && u.currentHp > 0);
    const negativeStatuses: StatusEffectId[] = [
      'poisoned','badlyPoisoned','leeched','burned','wet','paralyzed',
      'confused','ragebaited','occupied','bruised','intimidated',
    ];
    return (
      <div className="p-3 bg-gray-900 border-t border-gray-700 space-y-2">
        <div className="flex items-center gap-2">
          <button onClick={() => setPanel('ability')} className="text-gray-400 hover:text-white text-sm">← Back</button>
          <span className="text-blue-400 font-bold text-sm">Magical Orb - Select targets & status</span>
        </div>
        <div className="flex flex-wrap gap-1">
          {enemies.map((e) => (
            <button
              key={e.unitId}
              onClick={() => setZachyTargets((t) => t.includes(e.unitId) ? t.filter((x) => x !== e.unitId) : [...t, e.unitId])}
              className={`px-2 py-1 rounded text-xs font-bold transition-all active:scale-95 ${zachyTargets.includes(e.unitId) ? 'bg-blue-600 text-white ring-2 ring-yellow-400' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'}`}
            >
              {e.emoji} {e.name}
            </button>
          ))}
        </div>
        <div className="flex flex-wrap gap-1">
          {negativeStatuses.map((s) => {
            const def = STATUS_EFFECTS[s];
            return (
              <button
                key={s}
                onClick={() => setZachyStatus(s)}
                className={`px-2 py-1 rounded text-xs font-bold transition-all active:scale-95 ${zachyStatus === s ? 'ring-2 ring-yellow-400' : ''}`}
                style={{ backgroundColor: def.bgColor, color: def.color, border: `1px solid ${def.color}` }}
              >
                {def.emoji} {def.name}
              </button>
            );
          })}
        </div>
        <button
          disabled={zachyTargets.length === 0}
          onClick={() => {
            dispatch({ type: 'COMBAT_USE_ZACHY_ORB', targetIds: zachyTargets, statusId: zachyStatus });
            setPanel('main');
            setZachyTargets([]);
          }}
          className={btnClass(zachyTargets.length === 0)}
        >
          Launch Orb at {zachyTargets.length} target(s) with {STATUS_EFFECTS[zachyStatus].name}
        </button>
      </div>
    );
  }

  if (panel === 'ability') {
    const charDef = activeUnit.isPlayer ? CHARACTERS[activeUnit.sourceId as string] : null;
    if (!charDef) return null;

    return (
      <div className="p-3 bg-gray-900 border-t border-gray-700 space-y-2">
        <div className="flex items-center gap-2 mb-1">
          <button onClick={() => setPanel('main')} className="text-gray-400 hover:text-white text-sm">← Back</button>
          <span className="text-yellow-400 font-bold text-sm">Active Ability</span>
        </div>
        <div className="bg-gray-800 rounded-lg p-3">
          <div className="font-bold text-yellow-300 text-sm">{charDef.active.name}</div>
          <div className="text-gray-400 text-xs mt-1">{charDef.active.description}</div>
        </div>
        <button
          disabled={!canAbility}
          onClick={() => {
            if (activeUnit.sourceId === 'zachy') { setPanel('zachyOrb'); return; }
            if (activeUnit.sourceId === 'davy') dispatch({ type: 'COMBAT_USE_DAVY_YT' });
            else if (activeUnit.sourceId === 'granty' && !activeUnit.fruitSnacksActive) dispatch({ type: 'COMBAT_USE_GRANTY_FRUITSNACKS' });
            else if (activeUnit.sourceId === 'granty') dispatch({ type: 'COMBAT_TOGGLE_CHUD' });
            else if (activeUnit.sourceId === 'meggie') dispatch({ type: 'COMBAT_USE_MEGGIE_FLUTE' });
            setPanel('main');
          }}
          className={`w-full ${btnClass(!canAbility)}`}
          style={canAbility ? { backgroundColor: activeUnit.color } : undefined}
        >
          Use {charDef.active.name}
        </button>
        {activeUnit.sourceId === 'granty' && (
          <button
            onClick={() => { dispatch({ type: 'COMBAT_TOGGLE_CHUD' }); setPanel('main'); }}
            className="w-full px-3 py-2 rounded-lg font-bold text-sm bg-green-700 hover:bg-green-600 text-white transition-all active:scale-95"
          >
            {activeUnit.chudActive ? 'Deactivate' : 'Activate'} Chud Stance
          </button>
        )}
      </div>
    );
  }

  if (panel === 'special') {
    return (
      <div className="p-3 bg-gray-900 border-t border-gray-700 space-y-2">
        <div className="flex items-center gap-2 mb-1">
          <button onClick={() => setPanel('main')} className="text-gray-400 hover:text-white text-sm">← Back</button>
          <span className="text-purple-400 font-bold text-sm">Special Actions</span>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => { dispatch({ type: 'COMBAT_SPECIAL_DODGE' }); setPanel('main'); }}
            disabled={actionsUsed.ability}
            className={btnClass(actionsUsed.ability)}
          >
            🛡 Dodge<div className="text-xs font-normal opacity-70">60% acc vs you</div>
          </button>
          <button
            onClick={() => { dispatch({ type: 'COMBAT_SPECIAL_DISENGAGE' }); setPanel('main'); }}
            disabled={actionsUsed.ability}
            className={btnClass(actionsUsed.ability)}
          >
            🏃 Disengage<div className="text-xs font-normal opacity-70">No opp. attacks</div>
          </button>
          <button
            onClick={() => { dispatch({ type: 'COMBAT_SPECIAL_HEAL' }); setPanel('main'); }}
            disabled={actionsUsed.ability}
            className={btnClass(actionsUsed.ability)}
          >
            💊 Heal<div className="text-xs font-normal opacity-70">Reduce a status</div>
          </button>
          <button
            onClick={() => { dispatch({ type: 'COMBAT_SPECIAL_ROOT' }); setPanel('main'); }}
            disabled={actionsUsed.moved || actionsUsed.ability}
            className={btnClass(actionsUsed.moved || actionsUsed.ability)}
          >
            ⚓ Root In Place<div className="text-xs font-normal opacity-70">+50% dmg, no move</div>
          </button>
        </div>
      </div>
    );
  }

  // Main panel
  return (
    <div className="p-3 bg-gray-900 border-t border-gray-700">
      {/* Character info bar */}
      <div className="flex items-center gap-2 mb-2">
        <div className="w-8 h-8 rounded-full flex items-center justify-center text-lg" style={{ backgroundColor: activeUnit.color }}>
          {activeUnit.emoji}
        </div>
        <div>
          <div className="text-white font-bold text-sm">{activeUnit.name}'s Turn</div>
          <div className="text-gray-400 text-xs">HP: {activeUnit.currentHp}/{activeUnit.stats.maxHp}</div>
        </div>
        <div className="ml-auto flex gap-1 text-xs">
          {actionsUsed.moved && <span className="px-1.5 py-0.5 bg-gray-700 text-gray-400 rounded">Moved</span>}
          {actionsUsed.attacked && <span className="px-1.5 py-0.5 bg-gray-700 text-gray-400 rounded">Attacked</span>}
          {actionsUsed.ability && <span className="px-1.5 py-0.5 bg-gray-700 text-gray-400 rounded">Ability Used</span>}
        </div>
      </div>

      {/* Action buttons */}
      <div className="grid grid-cols-5 gap-1.5">
        <button
          disabled={actionsUsed.moved || activeUnit.chudActive}
          onClick={() => {
            if (cs.selectedAction === 'move') selectAction('none');
            else selectAction('move');
          }}
          className={`py-2 rounded-lg font-bold text-xs transition-all duration-150 active:scale-90 ${
            actionsUsed.moved || activeUnit.chudActive
              ? 'bg-gray-700 text-gray-500 cursor-not-allowed opacity-50'
              : cs.selectedAction === 'move'
              ? 'bg-cyan-400 text-gray-900 shadow-lg shadow-cyan-400/30 scale-105'
              : 'bg-cyan-700 hover:bg-cyan-600 text-white'
          }`}
        >
          🚶 Move
        </button>
        <button
          disabled={!canAttack}
          onClick={() => {
            if (cs.selectedAction === 'attack') selectAction('none');
            else selectAction('attack');
          }}
          className={`py-2 rounded-lg font-bold text-xs transition-all duration-150 active:scale-90 ${
            !canAttack
              ? 'bg-gray-700 text-gray-500 cursor-not-allowed opacity-50'
              : cs.selectedAction === 'attack'
              ? 'bg-red-400 text-gray-900 shadow-lg shadow-red-400/30 scale-105'
              : 'bg-red-700 hover:bg-red-600 text-white'
          }`}
        >
          ⚔️ Attack
        </button>
        <button
          disabled={!canAbility || !activeUnit.isPlayer}
          onClick={() => { setPanel('ability'); selectAction('none'); }}
          className={`py-2 rounded-lg font-bold text-xs transition-all duration-150 active:scale-90 ${
            !canAbility || !activeUnit.isPlayer
              ? 'bg-gray-700 text-gray-500 cursor-not-allowed opacity-50'
              : 'text-white'
          }`}
          style={canAbility && activeUnit.isPlayer ? { backgroundColor: activeUnit.color } : undefined}
        >
          ✨ Ability
        </button>
        <button
          disabled={actionsUsed.ability}
          onClick={() => { setPanel('special'); selectAction('none'); }}
          className={`py-2 rounded-lg font-bold text-xs transition-all duration-150 active:scale-90 ${
            actionsUsed.ability
              ? 'bg-gray-700 text-gray-500 cursor-not-allowed opacity-50'
              : 'bg-purple-700 hover:bg-purple-600 text-white'
          }`}
        >
          🎭 Special
        </button>
        <button
          onClick={() => dispatch({ type: 'COMBAT_END_TURN' })}
          className="py-2 rounded-lg font-bold text-xs bg-gray-600 hover:bg-gray-500 text-white transition-all duration-150 active:scale-90"
        >
          ⏭ End Turn
        </button>
      </div>
    </div>
  );
}
