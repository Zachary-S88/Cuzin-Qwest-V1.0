import React, { useState, useCallback } from 'react';
import { GameProvider, useGame } from './contexts/GameContext';
import TitleScreen from './screens/TitleScreen';
import OpeningScene from './screens/OpeningScene';
import HubScreen from './screens/HubScreen';
import ExplorationScreen from './screens/ExplorationScreen';
import CombatScreen from './screens/CombatScreen';
import BossChoiceScreen from './screens/BossChoiceScreen';
import DevMenu from './components/DevMenu';
import { useDevMenu } from './hooks/useDevMenu';

function GameApp() {
  const { state } = useGame();
  const [devOpen, setDevOpen] = useState(false);

  const openDev = useCallback(() => setDevOpen(true), []);
  useDevMenu(openDev);

  const screenMap: Record<typeof state.screen, React.ReactNode> = {
    title: <TitleScreen />,
    opening: <OpeningScene />,
    hub: <HubScreen />,
    exploration: <ExplorationScreen />,
    combat: <CombatScreen />,
    bossChoice: <BossChoiceScreen />,
    gameOver: (
      <div className="fixed inset-0 flex items-center justify-center bg-gray-950">
        <div className="text-white font-black text-2xl">Game Over</div>
      </div>
    ),
    victory: (
      <div className="fixed inset-0 flex items-center justify-center bg-gray-950">
        <div className="text-yellow-400 font-black text-2xl">Victory!</div>
      </div>
    ),
  };

  return (
    <div className="w-full h-full" style={{ fontFamily: 'Nunito, sans-serif' }}>
      {screenMap[state.screen] ?? <TitleScreen />}
      {devOpen && <DevMenu onClose={() => setDevOpen(false)} />}
    </div>
  );
}

export default function App() {
  return (
    <GameProvider>
      <GameApp />
    </GameProvider>
  );
}
