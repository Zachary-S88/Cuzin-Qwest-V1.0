import type { ExplorationState, MapEnemy } from './types';

const LAKE_WIDTH = 32;
const LAKE_HEIGHT = 16;

export const LAKE_MAP = {
  width: LAKE_WIDTH,
  height: LAKE_HEIGHT,
};

export function generateLakeEnemies(): MapEnemy[] {
  return [
    { instanceId: 'lake_e1', enemyId: 'aquaGloop', position: { x: 8, y: 5 }, defeated: false, isBoss: false, level: 1 },
    { instanceId: 'lake_e2', enemyId: 'aquaGloop', position: { x: 10, y: 10 }, defeated: false, isBoss: false, level: 1 },
    { instanceId: 'lake_e3', enemyId: 'lakeLurker', position: { x: 14, y: 7 }, defeated: false, isBoss: false, level: 2 },
    { instanceId: 'lake_e4', enemyId: 'shoreCrawler', position: { x: 18, y: 4 }, defeated: false, isBoss: false, level: 2 },
    { instanceId: 'lake_e5', enemyId: 'lakeLurker', position: { x: 22, y: 9 }, defeated: false, isBoss: false, level: 3 },
    { instanceId: 'lake_boss', enemyId: 'shelly', position: { x: 28, y: 6 }, defeated: false, isBoss: true, level: 5 },
  ];
}

export function initialExplorationState(): ExplorationState {
  return {
    area: 'lake',
    playerPosition: { x: 2, y: 7 },
    enemies: generateLakeEnemies(),
    completedEvents: [],
    fortressStepsTaken: 0,
  };
}

export function getLakeTileType(x: number, y: number): string {
  if (y === 0 || y === LAKE_HEIGHT - 1) return 'grass';
  if (y === 1 || y === LAKE_HEIGHT - 2) return 'shallowWater';
  if (x >= LAKE_WIDTH - 5 && (y >= 4 && y <= LAKE_HEIGHT - 4)) return 'fortress';
  if (x >= LAKE_WIDTH - 6 && (y === 3 || y === LAKE_HEIGHT - 3)) return 'fortressWall';
  return 'water';
}
