import type { PartyMember, BaseStats, CharacterId } from './types';
import { CHARACTERS } from './characters';

export const XP_TABLE: number[] = Array.from({ length: 50 }, (_, i) =>
  Math.floor(100 * Math.pow(1.5, i))
);

export function xpToNextLevel(level: number): number {
  return XP_TABLE[Math.min(level - 1, 49)];
}

export function addXp(member: PartyMember, amount: number): { member: PartyMember; levelUps: number } {
  const m = { ...member };
  let levelUps = 0;

  m.xp += amount;

  while (m.level < 50 && m.xp >= m.xpToNext) {
    m.xp -= m.xpToNext;
    m.level += 1;
    levelUps++;
    m.xpToNext = xpToNextLevel(m.level);

    m.bonusStats = {
      maxHp: (m.bonusStats.maxHp ?? 0) + 1,
      attack: (m.bonusStats.attack ?? 0) + 1,
      defense: (m.bonusStats.defense ?? 0) + 1,
      speed: (m.bonusStats.speed ?? 0) + 1,
      special: (m.bonusStats.special ?? 0) + 1,
    };
  }

  return { member: m, levelUps };
}

export function getEffectiveStats(member: PartyMember): BaseStats & { maxHp: number } {
  return {
    maxHp: def.baseStats.maxHp + (member.bonusStats.maxHp ?? 0),
    attack: def.baseStats.attack + (member.bonusStats.attack ?? 0),
    defense: def.baseStats.defense + (member.bonusStats.defense ?? 0),
    speed: def.baseStats.speed + (member.bonusStats.speed ?? 0),
    special: def.baseStats.special + (member.bonusStats.special ?? 0),
  };
}

export function createPartyMember(characterId: CharacterId): PartyMember {
  const def = CHARACTERS[characterId];
  return {
    characterId,
    level: 1,
    xp: 0,
    xpToNext: xpToNextLevel(1),
    currentHp: def.baseStats.maxHp,
    bonusStats: {},
  };
}
