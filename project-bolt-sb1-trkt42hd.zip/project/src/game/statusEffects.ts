import type { StatusEffectId, ActiveStatusEffect, CombatUnit, DamageNumber } from './types';

export interface StatusEffectDefinition {
  id: StatusEffectId;
  name: string;
  description: string;
  color: string;
  bgColor: string;
  emoji: string;
  isPositive: boolean;
  defaultTurns: number | null; // null = indefinite
  defaultHealCount: number;    // how many heals to remove manually
}

export const STATUS_EFFECTS: Record<StatusEffectId, StatusEffectDefinition> = {
  poisoned: {
    id: 'poisoned',
    name: 'Poisoned',
    description: 'Take 10% max HP damage at the start of each turn.',
    color: '#a855f7',
    bgColor: 'rgba(168, 85, 247, 0.3)',
    emoji: '💀',
    isPositive: false,
    defaultTurns: null,
    defaultHealCount: 3,
  },
  badlyPoisoned: {
    id: 'badlyPoisoned',
    name: 'Badly Poisoned',
    description: 'Take damage at start of turn: starts at 5% max HP and doubles each tick.',
    color: '#7c3aed',
    bgColor: 'rgba(124, 58, 237, 0.3)',
    emoji: '☠️',
    isPositive: false,
    defaultTurns: null,
    defaultHealCount: 3,
  },
  leeched: {
    id: 'leeched',
    name: 'Leeched',
    description: 'Take 12% max HP damage at start of turn. The attacker heals for the same amount.',
    color: '#16a34a',
    bgColor: 'rgba(22, 163, 74, 0.3)',
    emoji: '🌱',
    isPositive: false,
    defaultTurns: null,
    defaultHealCount: 3,
  },
  burned: {
    id: 'burned',
    name: 'Burned',
    description: 'Take 6% max HP damage per turn. Weapon attacks deal half damage (miss if < 1).',
    color: '#dc2626',
    bgColor: 'rgba(220, 38, 38, 0.3)',
    emoji: '🔥',
    isPositive: false,
    defaultTurns: null,
    defaultHealCount: 3,
  },
  wet: {
    id: 'wet',
    name: 'Wet',
    description: 'Weapon attack accuracy halved. Moving forces a straight-line slide.',
    color: '#3b82f6',
    bgColor: 'rgba(59, 130, 246, 0.3)',
    emoji: '💧',
    isPositive: false,
    defaultTurns: 3,
    defaultHealCount: 1,
  },
  paralyzed: {
    id: 'paralyzed',
    name: 'Paralyzed',
    description: 'Speed halved. 1/3 chance at start of turn to skip attacks and abilities.',
    color: '#eab308',
    bgColor: 'rgba(234, 179, 8, 0.3)',
    emoji: '⚡',
    isPositive: false,
    defaultTurns: 3,
    defaultHealCount: 2,
  },
  confused: {
    id: 'confused',
    name: 'Confused',
    description: 'Move half speed in a random direction. Can\'t use abilities. -25% weapon accuracy.',
    color: '#06b6d4',
    bgColor: 'rgba(6, 182, 212, 0.3)',
    emoji: '😵',
    isPositive: false,
    defaultTurns: 3,
    defaultHealCount: 2,
  },
  ragebaited: {
    id: 'ragebaited',
    name: 'Ragebaited',
    description: 'Can only move and attack. Attacks do 25% more damage but 1/4 chance to hit ally/self.',
    color: '#ef4444',
    bgColor: 'rgba(239, 68, 68, 0.3)',
    emoji: '😡',
    isPositive: false,
    defaultTurns: null,
    defaultHealCount: 3,
  },
  occupied: {
    id: 'occupied',
    name: 'Occupied',
    description: 'Can\'t make weapon attacks. Speed halved. Attacks against you are 25% more accurate.',
    color: '#64748b',
    bgColor: 'rgba(100, 116, 139, 0.3)',
    emoji: '🤔',
    isPositive: false,
    defaultTurns: 2,
    defaultHealCount: 1,
  },
  bruised: {
    id: 'bruised',
    name: 'Bruised',
    description: 'Take 50% more damage from weapon attacks.',
    color: '#7c3aed',
    bgColor: 'rgba(124, 58, 237, 0.3)',
    emoji: '🥲',
    isPositive: false,
    defaultTurns: 3,
    defaultHealCount: 2,
  },
  intimidated: {
    id: 'intimidated',
    name: 'Intimidated',
    description: '-25% damage and accuracy. No benefit from passive or active abilities.',
    color: '#f97316',
    bgColor: 'rgba(249, 115, 22, 0.3)',
    emoji: '😨',
    isPositive: false,
    defaultTurns: 3,
    defaultHealCount: 2,
  },
  metal: {
    id: 'metal',
    name: 'Metal',
    description: 'Take half damage from all sources. Can\'t gain negative statuses. Speed halved.',
    color: '#94a3b8',
    bgColor: 'rgba(148, 163, 184, 0.3)',
    emoji: '🙂',
    isPositive: true,
    defaultTurns: null,
    defaultHealCount: 0,
  },
  recuperation: {
    id: 'recuperation',
    name: 'Recuperation',
    description: 'Gain 10% max HP at start of turn. Timed negative statuses reduced by 1 per heal.',
    color: '#22c55e',
    bgColor: 'rgba(34, 197, 94, 0.3)',
    emoji: '🏥',
    isPositive: true,
    defaultTurns: null,
    defaultHealCount: 0,
  },
  coached: {
    id: 'coached',
    name: 'Coached',
    description: '+25% weapon accuracy and +25% weapon damage.',
    color: '#3b82f6',
    bgColor: 'rgba(59, 130, 246, 0.3)',
    emoji: '👍',
    isPositive: true,
    defaultTurns: null,
    defaultHealCount: 0,
  },
  invisible: {
    id: 'invisible',
    name: 'Invisible',
    description: 'Enemies can\'t see you. Weapon attacks auto-miss you. Abilities 50% fail. Your attacks +25% accuracy and damage.',
    color: '#e2e8f0',
    bgColor: 'rgba(226, 232, 240, 0.2)',
    emoji: '🫥',
    isPositive: true,
    defaultTurns: null,
    defaultHealCount: 0,
  },
};

export function createStatusEffect(
  id: StatusEffectId,
  overrideTurns?: number | null
): ActiveStatusEffect {
  const def = STATUS_EFFECTS[id];
  return {
    id,
    turnsRemaining: overrideTurns !== undefined ? overrideTurns : def.defaultTurns,
    healCount: 0,
    stackMultiplier: 1,
  };
}

export function hasStatus(unit: CombatUnit, id: StatusEffectId): boolean {
  return unit.statusEffects.some((e) => e.id === id);
}

export function getStatus(unit: CombatUnit, id: StatusEffectId): ActiveStatusEffect | undefined {
  return unit.statusEffects.find((e) => e.id === id);
}

export function addStatus(
  unit: CombatUnit,
  id: StatusEffectId,
  overrideTurns?: number | null
): CombatUnit {
  // Metal prevents negative status
  if (hasStatus(unit, 'metal') && !STATUS_EFFECTS[id].isPositive) return unit;
  // Intimidated prevents passive/active benefits - handled elsewhere
  // Don't stack same status, just reset it
  const existing = unit.statusEffects.filter((e) => e.id !== id);
  return {
    ...unit,
    statusEffects: [...existing, createStatusEffect(id, overrideTurns)],
  };
}

export function removeStatus(unit: CombatUnit, id: StatusEffectId): CombatUnit {
  return {
    ...unit,
    statusEffects: unit.statusEffects.filter((e) => e.id !== id),
  };
}

export function tickStatusEffects(unit: CombatUnit): {
  unit: CombatUnit;
  dotDamage: number;
  leechHealForSource: number;
  leechSourceId?: string;
  log: string[];
} {
  let current = { ...unit };
  let dotDamage = 0;
  const log: string[] = [];

  // Process start-of-turn status damage
  for (const effect of current.statusEffects) {
    switch (effect.id) {
      case 'poisoned': {
        const dmg = Math.max(1, Math.floor(unit.stats.maxHp * 0.1));
        dotDamage += dmg;
        log.push(`${unit.name} takes ${dmg} poison damage!`);
        break;
      }
      case 'badlyPoisoned': {
        const dmg = Math.max(1, Math.floor(unit.stats.maxHp * 0.05 * effect.stackMultiplier));
        dotDamage += dmg;
        log.push(`${unit.name} takes ${dmg} bad poison damage!`);
        break;
      }
      case 'leeched': {
        const dmg = Math.max(1, Math.floor(unit.stats.maxHp * 0.12));
        dotDamage += dmg;
        log.push(`${unit.name} is leeched for ${dmg} HP!`);
        break;
      }
      case 'burned': {
        const dmg = Math.max(1, Math.floor(unit.stats.maxHp * 0.06));
        dotDamage += dmg;
        log.push(`${unit.name} burns for ${dmg} damage!`);
        break;
      }
      case 'recuperation': {
        const heal = Math.max(1, Math.floor(unit.stats.maxHp * 0.1));
        current = {
          ...current,
          currentHp: Math.min(current.stats.maxHp, current.currentHp + heal),
        };
        log.push(`${unit.name} recovers ${heal} HP from recuperation!`);
        break;
      }
    }
  }

  // Tick turns remaining and update badly poisoned multiplier
  const updatedEffects = current.statusEffects
    .map((e) => {
      if (e.id === 'badlyPoisoned') {
        return { ...e, stackMultiplier: e.stackMultiplier * 2 };
      }
      if (e.turnsRemaining !== null) {
        return { ...e, turnsRemaining: e.turnsRemaining - 1 };
      }
      return e;
    })
    .filter((e) => e.turnsRemaining === null || e.turnsRemaining > 0);

  // Apply recuperation to negative status timers
  if (hasStatus(current, 'recuperation') && dotDamage === 0) {
    // Only reduce if we healed (no dot damage this tick actually)
  }

  current = {
    ...current,
    currentHp: Math.max(0, current.currentHp - dotDamage),
    statusEffects: updatedEffects,
  };

  return { unit: current, dotDamage, leechHealForSource: 0, log };
}

export function generateDamageNumberId(): string {
  return `dmg_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

export function makeDamageNumber(
  value: number | string,
  x: number,
  y: number,
  type: DamageNumber['type']
): DamageNumber {
  return {
    id: generateDamageNumberId(),
    value,
    x,
    y,
    type,
    createdAt: Date.now(),
  };
}
