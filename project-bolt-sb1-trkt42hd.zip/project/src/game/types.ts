// ─── Screen / Game Flow ───────────────────────────────────────────────────────

export type GameScreen =
  | 'title'
  | 'opening'
  | 'hub'
  | 'exploration'
  | 'combat'
  | 'bossChoice'
  | 'gameOver'
  | 'victory';

export type Difficulty = 'easy' | 'normal' | 'hard';

// ─── Characters ───────────────────────────────────────────────────────────────

export type CharacterId =
  | 'zachy'
  | 'davy'
  | 'granty'
  | 'whyWhy'
  | 'meggie';

export type EnemyId =
  | 'aquaGloop'
  | 'lakeLurker'
  | 'shoreCrawler'
  | 'shelly'
  | 'kevin';

export type UnitId = CharacterId | EnemyId;

export type MeggieDemeanor = 'silly' | 'intimidating' | 'tough' | 'studious';

// ─── Stats ────────────────────────────────────────────────────────────────────

export interface BaseStats {
  maxHp: number;
  attack: number;
  defense: number;
  speed: number;
  special: number;
}

// ─── Status Effects ───────────────────────────────────────────────────────────

export type StatusEffectId =
  | 'poisoned'
  | 'badlyPoisoned'
  | 'leeched'
  | 'burned'
  | 'wet'
  | 'paralyzed'
  | 'confused'
  | 'ragebaited'
  | 'occupied'
  | 'bruised'
  | 'intimidated'
  | 'metal'
  | 'recuperation'
  | 'coached'
  | 'invisible';

export interface ActiveStatusEffect {
  id: StatusEffectId;
  turnsRemaining: number | null; // null = indefinite / must be healed
  healCount: number;             // times heal action used on this effect
  stackMultiplier: number;       // for badly poisoned damage doubling
}

// ─── Combat Buffs (from abilities, displayed as solid squares) ────────────────

export interface CombatBuff {
  id: string;
  name: string;
  description: string;
  color: string;
  isBuff: boolean;
}

// ─── Position ─────────────────────────────────────────────────────────────────

export interface Position {
  x: number; // column (0-indexed)
  y: number; // row (0-indexed)
}

// ─── Combat Units ─────────────────────────────────────────────────────────────

export interface ActionsUsed {
  moved: boolean;
  attacked: boolean;
  ability: boolean;
  reaction: boolean;
}

export interface CombatUnit {
  unitId: string;
  sourceId: UnitId;
  name: string;
  isPlayer: boolean;
  isBoss: boolean;
  currentHp: number;
  stats: BaseStats & { maxHp: number };
  baseStats: BaseStats & { maxHp: number };
  level: number;
  position: Position;
  statusEffects: ActiveStatusEffect[];
  actionsUsed: ActionsUsed;
  combatBuffs: CombatBuff[];
  // Meggie only
  demeanor?: MeggieDemeanor;
  // Zachy: track per-enemy accuracy/damage bonuses
  zachyMissTracker?: Record<string, { accuracyBonus: number; damageBonus: number }>;
  // Granty: chud stance
  chudActive?: boolean;
  // Granty: fruit snacks buff
  fruitSnacksActive?: boolean;
  // Davy: invisible via YT Shorts
  ytShortsUntilTurn?: number;
  // Meggie: flute solo targets (who was in range)
  fluteSoloTargets?: string[];
  // Kevin: blitz first-attack-bonus tracking
  blitzUsed?: boolean;
  color: string;
  emoji: string;
}

// ─── Tiles ────────────────────────────────────────────────────────────────────

export type TileType =
  | 'water'
  | 'shallowWater'
  | 'grass'
  | 'path'
  | 'stone'
  | 'sand'
  | 'lilyPad'
  | 'tree'
  | 'fortressWall'
  | 'fortressFloor';

export interface Tile {
  type: TileType;
  passable: boolean;
  isObstacle: boolean; // blocks movement/line of sight
}

export type CombatEnvironment = 'lake' | 'grass' | 'fortress';

// ─── Combat State ─────────────────────────────────────────────────────────────

export type CombatPhase =
  | 'player_turn'
  | 'enemy_turn'
  | 'animating'
  | 'reaction_prompt'
  | 'victory'
  | 'defeat';

export type SelectedAction =
  | 'none'
  | 'move'
  | 'attack'
  | 'ability'
  | 'special';

export type SpecialActionId =
  | 'dodge'
  | 'disengage'
  | 'heal'
  | 'rootInPlace'
  | 'giveChase'
  | 'opportunityAttack';

export interface DamageNumber {
  id: string;
  value: number | string;
  x: number;
  y: number;
  type: 'damage' | 'heal' | 'miss' | 'critical' | 'status';
  createdAt: number;
}

export interface CombatLogEntry {
  id: string;
  message: string;
  type: 'attack' | 'ability' | 'status' | 'system' | 'death' | 'move';
  createdAt: number;
}

export interface PendingReaction {
  type: 'opportunityAttack' | 'giveChase';
  reactingUnitId: string;
  triggeringUnitId: string;
  triggeringPosition: Position;
}

export interface CombatState {
  grid: Tile[][];
  gridWidth: number;
  gridHeight: number;
  units: CombatUnit[];
  turnOrder: string[];         // unitIds in speed order
  currentTurnIndex: number;
  phase: CombatPhase;
  selectedAction: SelectedAction;
  activeUnitId: string | null;
  highlightedTiles: Position[];   // movement or range highlights
  targetTiles: Position[];        // attack target highlights
  damageNumbers: DamageNumber[];
  log: CombatLogEntry[];
  environment: CombatEnvironment;
  isBossFight: boolean;
  pendingReaction: PendingReaction | null;
  isShaking: boolean;
  turnCount: number;
  pendingEnemyActions: (() => void)[];
}

// ─── Exploration ──────────────────────────────────────────────────────────────

export type ExplorationArea = 'hub' | 'lake';

export interface MapEnemy {
  instanceId: string;
  enemyId: EnemyId;
  position: Position;
  defeated: boolean;
  isBoss: boolean;
  level: number;
}

export interface ExplorationState {
  area: ExplorationArea;
  playerPosition: Position;
  enemies: MapEnemy[];
  completedEvents: string[];
  fortressStepsTaken: number;
}

// ─── Story / Flags ────────────────────────────────────────────────────────────

export interface StoryFlags {
  openingComplete: boolean;
  bossDefeated: boolean;
  rescuedCuzin: CharacterId | null;
  visitedHub: boolean;
  lakeEnemiesDefeated: number;
}

// ─── Party / Progression ──────────────────────────────────────────────────────

export interface PartyMember {
  characterId: CharacterId;
  level: number;
  xp: number;
  xpToNext: number;
  currentHp: number;
  bonusStats: Partial<BaseStats>; // accumulated from level-ups
}

// ─── Full Game State ──────────────────────────────────────────────────────────

export interface GameState {
  screen: GameScreen;
  party: PartyMember[];
  activeCharacterId: CharacterId;
  unlockedCharacters: CharacterId[];
  storyFlags: StoryFlags;
  explorationState: ExplorationState;
  combatState: CombatState | null;
  difficulty: Difficulty;
  sessionId: string;
  pendingCombat: PendingCombatInfo | null;
}

export interface PendingCombatInfo {
  enemyIds: EnemyId[];
  enemyLevels: number[];
  environment: CombatEnvironment;
  isBossFight: boolean;
  triggerInstanceId?: string; // map enemy instanceId
}

// ─── Character Definitions (static data) ─────────────────────────────────────

export interface CharacterDefinition {
  id: CharacterId;
  name: string;
  tagline: string;
  color: string;
  secondaryColor: string;
  emoji: string;
  baseStats: BaseStats & { maxHp: number };
  weapon: WeaponDef;
  passive: PassiveDef;
  active: ActiveDef;
}

export interface WeaponDef {
  name: string;
  description: string;
  rangeInTiles: number;
  isAoe: boolean;
  aoeRadiusTiles?: number;
}

export interface PassiveDef {
  name: string;
  description: string;
}

export interface ActiveDef {
  name: string;
  description: string;
  rangeInTiles: number;
  isMultiTarget: boolean;
}

// ─── Enemy Definitions (static data) ─────────────────────────────────────────

export interface EnemyDefinition {
  id: EnemyId;
  name: string;
  color: string;
  emoji: string;
  isBoss: boolean;
  baseStats: BaseStats & { maxHp: number };
  weapon: WeaponDef;
  passive?: PassiveDef;
  active?: ActiveDef;
  xpReward: number;
  aiType: 'aggressive' | 'support' | 'balanced';
}
