import type { CharacterDefinition, EnemyDefinition } from './types';

export const CHARACTERS: Record<string, CharacterDefinition> = {
  zachy: {
    id: 'zachy',
    name: 'Zachy',
    tagline: 'The Wizard Cuzin',
    color: '#3b82f6',
    secondaryColor: '#f59e0b',
    emoji: '🧙',
    baseStats: { maxHp: 20, attack: 10, defense: 20, speed: 20, special: 30 },
    weapon: {
      name: 'Spinning Wrench',
      description:
        'Attacks all enemies within 10 ft (2 tiles) in a circle. Pushes them back 15 ft (3 tiles). Area-of-effect.',
      rangeInTiles: 2,
      isAoe: true,
      aoeRadiusTiles: 2,
    },
    passive: {
      name: 'Erm, Actually',
      description:
        "Weapon attacks against Zachy and allies within 10 ft are 40% less likely to hit. Each miss against Zachy permanently gives him +25% accuracy and +25% damage against that enemy for this combat.",
    },
    active: {
      name: 'Magical Orb',
      description:
        'Shoot a magical orb at up to 3 targets within 100 ft. Each target takes 15% of their max HP as damage. You choose a negative status condition — all targets gain it for 5 turns.',
      rangeInTiles: 20,
      isMultiTarget: true,
    },
  },

  davy: {
    id: 'davy',
    name: 'Davy',
    tagline: 'The Speed Demon',
    color: '#92400e',
    secondaryColor: '#fbbf24',
    emoji: '🎹',
    baseStats: { maxHp: 10, attack: 20, defense: 10, speed: 40, special: 20 },
    weapon: {
      name: 'Loud Aah Keyboard',
      description:
        'Types "attack" loudly at a single enemy within 60 ft. 60% chance to apply Occupied.',
      rangeInTiles: 12,
      isAoe: false,
    },
    passive: {
      name: 'I Guess, Bro',
      description:
        'When Davy attacks or is attacked, the other party gains Ragebaited until they attack someone other than Davy.',
    },
    active: {
      name: 'Scroll YT Shorts',
      description:
        'Davy crouches to scroll shorts. Gains Invisible until the end of his next turn and takes 25% less damage until then.',
      rangeInTiles: 0,
      isMultiTarget: false,
    },
  },

  granty: {
    id: 'granty',
    name: 'Granty',
    tagline: 'The Silly Brawler',
    color: '#15803d',
    secondaryColor: '#86efac',
    emoji: '🧦',
    baseStats: { maxHp: 10, attack: 30, defense: 20, speed: 30, special: 10 },
    weapon: {
      name: 'Suspicious Sock',
      description:
        'Swings his sock at a single target within 10 ft. 45% chance to Poison, 30% chance to Badly Poison.',
      rangeInTiles: 2,
      isAoe: false,
    },
    passive: {
      name: "I'm a Chud",
      description:
        'Toggle on/off on your turn. While active: cannot move, take 50% less damage, and gain Recuperation. While off: normal movement.',
    },
    active: {
      name: 'FRUIT SNACKS!!!',
      description:
        "Granty eats a whole pack of fruit snacks. For the rest of combat, speed is doubled and weapon attacks are 25% more accurate and deal 25% more damage. One use only.",
      rangeInTiles: 0,
      isMultiTarget: false,
    },
  },

  whyWhy: {
    id: 'whyWhy',
    name: 'Why Why',
    tagline: 'The Grumpy Tank',
    color: '#ca8a04',
    secondaryColor: '#fde68a',
    emoji: '😤',
    baseStats: { maxHp: 30, attack: 10, defense: 30, speed: 10, special: 20 },
    weapon: {
      name: 'Pillow Chuck',
      description:
        'Chucks a pillow at an enemy within 80 ft. Target is pushed back 10 ft (2 tiles) and deals 25% less damage until end of its next turn.',
      rangeInTiles: 16,
      isAoe: false,
    },
    passive: {
      name: 'Teary Eyes',
      description:
        'All weapon attacks against Why Why are at 80% base accuracy and deal 25% less damage.',
    },
    active: {
      name: 'Why?',
      description:
        'A target gains the Confused status. Why Why takes 25% less damage from all sources until the start of his next turn.',
      rangeInTiles: 10,
      isMultiTarget: false,
    },
  },

  meggie: {
    id: 'meggie',
    name: 'Meggie',
    tagline: 'The Wild Athlete',
    color: '#c2410c',
    secondaryColor: '#fdba74',
    emoji: '🎾',
    baseStats: { maxHp: 20, attack: 30, defense: 20, speed: 20, special: 10 },
    weapon: {
      name: 'Tennis Racket',
      description:
        'Smacks a tennis ball at an enemy within 120 ft. 50% chance to apply Bruised.',
      rangeInTiles: 24,
      isAoe: false,
    },
    passive: {
      name: 'Demeanor Change',
      description:
        'At the start of every combat, choose a demeanor: Silly (+50% speed, +25% accuracy), Intimidating (enemies who attack her 50% chance Intimidated, +25% weapon damage), Tough (25% less damage, can gain Recuperation as special action), or Studious (+25% accuracy and +25% damage).',
    },
    active: {
      name: 'Flute Solo',
      description:
        'Enemies within 60 ft have 60% chance to gain Distracted/Confused. Meggie\'s weapon attacks are 25% more accurate and do 25% more damage to anyone in range of the solo.',
      rangeInTiles: 12,
      isMultiTarget: true,
    },
  },
};

export const ENEMIES: Record<string, EnemyDefinition> = {
  aquaGloop: {
    id: 'aquaGloop',
    name: 'Aqua Gloop',
    color: '#0891b2',
    emoji: '💧',
    isBoss: false,
    baseStats: { maxHp: 12, attack: 8, defense: 5, speed: 15, special: 5 },
    weapon: {
      name: 'Slime Splash',
      description: 'Slaps with a watery appendage. 30% chance to apply Wet.',
      rangeInTiles: 1,
      isAoe: false,
    },
    xpReward: 15,
    aiType: 'aggressive',
  },

  lakeLurker: {
    id: 'lakeLurker',
    name: 'Lake Lurker',
    color: '#1d4ed8',
    emoji: '🌊',
    isBoss: false,
    baseStats: { maxHp: 18, attack: 12, defense: 8, speed: 20, special: 8 },
    weapon: {
      name: 'Water Jet',
      description: 'Fires a pressured jet of water. Range 4 tiles. 50% chance to Wet.',
      rangeInTiles: 4,
      isAoe: false,
    },
    passive: {
      name: 'Aquatic',
      description: 'Moves freely through water tiles.',
    },
    xpReward: 25,
    aiType: 'balanced',
  },

  shoreCrawler: {
    id: 'shoreCrawler',
    name: 'Shore Crawler',
    color: '#92400e',
    emoji: '🦀',
    isBoss: false,
    baseStats: { maxHp: 15, attack: 14, defense: 10, speed: 12, special: 5 },
    weapon: {
      name: 'Pincer Strike',
      description: 'Snaps claws at adjacent target. 40% chance to apply Bruised.',
      rangeInTiles: 1,
      isAoe: false,
    },
    xpReward: 20,
    aiType: 'aggressive',
  },

  shelly: {
    id: 'shelly',
    name: 'Shelly',
    color: '#be185d',
    emoji: '🐚',
    isBoss: true,
    baseStats: { maxHp: 80, attack: 15, defense: 30, speed: 15, special: 20 },
    weapon: {
      name: 'Shell Slam',
      description: 'Slams her shell shield into an adjacent foe. Chance to push them back 1 tile.',
      rangeInTiles: 1,
      isAoe: false,
    },
    passive: {
      name: 'Shell Shield',
      description: 'Takes 25% less damage from all sources.',
    },
    active: {
      name: 'Support Kevin',
      description: "Heals Kevin for 20% of his max HP and grants him Coached for 3 turns. Alternatively, grants herself Metal for 2 turns.",
      rangeInTiles: 8,
      isMultiTarget: false,
    },
    xpReward: 150,
    aiType: 'support',
  },

  kevin: {
    id: 'kevin',
    name: 'Kevin',
    color: '#dc2626',
    emoji: '⚡',
    isBoss: true,
    baseStats: { maxHp: 50, attack: 35, defense: 10, speed: 40, special: 15 },
    weapon: {
      name: 'Power Punch',
      description: 'A devastating haymaker on an adjacent target.',
      rangeInTiles: 1,
      isAoe: false,
    },
    passive: {
      name: 'Blitz',
      description: 'First attack each turn hits with +30% accuracy and deals +30% damage.',
    },
    active: {
      name: 'Double Strike',
      description: 'Makes two weapon attacks in one turn against the same or different targets.',
      rangeInTiles: 1,
      isMultiTarget: true,
    },
    xpReward: 200,
    aiType: 'aggressive',
  },
};
