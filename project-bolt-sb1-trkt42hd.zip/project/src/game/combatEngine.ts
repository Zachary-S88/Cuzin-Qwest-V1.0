import type {
  CombatState, CombatUnit, Position, Tile, TileType,
  CombatEnvironment, EnemyId, CharacterId, StatusEffectId,
  DamageNumber, CombatLogEntry,
} from './types';
import { CHARACTERS, ENEMIES } from './characters';
import {
  hasStatus, addStatus, tickStatusEffects,
  makeDamageNumber, STATUS_EFFECTS,
} from './statusEffects';

// ─── Grid Generation ──────────────────────────────────────────────────────────

function makeTile(type: TileType): Tile {
  const passable = type !== 'fortressWall' && type !== 'tree' && type !== 'lilyPad';
  return { type, passable, isObstacle: !passable };
}

export function generateGrid(env: CombatEnvironment, width: number, height: number): Tile[][] {
  const grid: Tile[][] = [];
  for (let y = 0; y < height; y++) {
    const row: Tile[] = [];
    for (let x = 0; x < width; x++) {
      let type: TileType = 'water';
      if (env === 'lake') {
        if (y === 0 || y === height - 1) type = 'grass';
        else if ((x + y * 3) % 13 === 0) type = 'lilyPad';
        else type = 'water';
      } else if (env === 'grass') {
        if ((x + y * 5) % 11 === 0) type = 'tree';
        else type = 'grass';
      } else if (env === 'fortress') {
        if (x === 0 || x === width - 1 || y === 0 || y === height - 1) type = 'fortressWall';
        else type = 'fortressFloor';
      }
      row.push(makeTile(type));
    }
    grid.push(row);
  }
  return grid;
}

// ─── Unit Factory ─────────────────────────────────────────────────────────────

let unitIdCounter = 0;

function nextUnitId() {
  return `unit_${++unitIdCounter}_${Math.random().toString(36).slice(2, 5)}`;
}

export function createPlayerUnit(
  characterId: CharacterId,
  level: number,
  currentHp: number,
  bonusStats: Partial<{ maxHp: number; attack: number; defense: number; speed: number; special: number }>,
  position: Position
): CombatUnit {
  const def = CHARACTERS[characterId];
  const base = { ...def.baseStats };
  const stats = {
    maxHp: base.maxHp + (bonusStats.maxHp ?? 0),
    attack: base.attack + (bonusStats.attack ?? 0),
    defense: base.defense + (bonusStats.defense ?? 0),
    speed: base.speed + (bonusStats.speed ?? 0),
    special: base.special + (bonusStats.special ?? 0),
  };
  return {
    unitId: nextUnitId(),
    sourceId: characterId,
    name: def.name,
    isPlayer: true,
    isBoss: false,
    currentHp: Math.min(currentHp, stats.maxHp),
    stats,
    baseStats: { ...stats },
    level,
    position,
    statusEffects: [],
    actionsUsed: { moved: false, attacked: false, ability: false, reaction: false },
    combatBuffs: [],
    color: def.color,
    emoji: def.emoji,
    zachyMissTracker: characterId === 'zachy' ? {} : undefined,
    chudActive: characterId === 'granty' ? false : undefined,
    fruitSnacksActive: characterId === 'granty' ? false : undefined,
    blitzUsed: false,
    fluteSoloTargets: [],
  };
}

export function createEnemyUnit(
  enemyId: EnemyId,
  level: number,
  position: Position
): CombatUnit {
  const def = ENEMIES[enemyId];
  const scaleFactor = 1 + (level - 1) * 0.15;
  const stats = {
    maxHp: Math.round(def.baseStats.maxHp * scaleFactor),
    attack: Math.round(def.baseStats.attack * scaleFactor),
    defense: Math.round(def.baseStats.defense * scaleFactor),
    speed: def.baseStats.speed,
    special: def.baseStats.special,
  };
  return {
    unitId: nextUnitId(),
    sourceId: enemyId,
    name: def.name,
    isPlayer: false,
    isBoss: def.isBoss,
    currentHp: stats.maxHp,
    stats,
    baseStats: { ...stats },
    level,
    position,
    statusEffects: [],
    actionsUsed: { moved: false, attacked: false, ability: false, reaction: false },
    combatBuffs: [],
    color: def.color,
    emoji: def.emoji,
    blitzUsed: false,
  };
}

// ─── Combat Initializer ───────────────────────────────────────────────────────

export function initCombat(
  partyMembers: Array<{ characterId: CharacterId; level: number; currentHp: number; bonusStats: Record<string, number> }>,
  enemyIds: EnemyId[],
  enemyLevels: number[],
  environment: CombatEnvironment,
  isBossFight: boolean
): CombatState {
  const width = isBossFight ? 20 : 16;
  const height = isBossFight ? 12 : 10;
  const grid = generateGrid(environment, width, height);

  const playerStartX = 1;
  const enemyStartX = width - 2;

  const playerUnits: CombatUnit[] = partyMembers.map((pm, i) =>
    createPlayerUnit(
      pm.characterId,
      pm.level,
      pm.currentHp,
      pm.bonusStats as Record<string, number>,
      { x: playerStartX, y: 2 + i * 2 }
    )
  );

  const enemyUnits: CombatUnit[] = enemyIds.map((id, i) =>
    createEnemyUnit(id, enemyLevels[i], { x: enemyStartX, y: 2 + i * 2 })
  );

  const allUnits = [...playerUnits, ...enemyUnits];
  const turnOrder = [...allUnits]
    .sort((a, b) => b.stats.speed - a.stats.speed)
    .map((u) => u.unitId);

  return {
    grid,
    gridWidth: width,
    gridHeight: height,
    units: allUnits,
    turnOrder,
    currentTurnIndex: 0,
    phase: 'player_turn',
    selectedAction: 'none',
    activeUnitId: turnOrder[0] ?? null,
    highlightedTiles: [],
    targetTiles: [],
    damageNumbers: [],
    log: [],
    environment,
    isBossFight,
    pendingReaction: null,
    isShaking: false,
    turnCount: 0,
    pendingEnemyActions: [],
  };
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

export function getUnit(state: CombatState, unitId: string): CombatUnit | undefined {
  return state.units.find((u) => u.unitId === unitId);
}

export function getLiveUnits(state: CombatState) {
  return state.units.filter((u) => u.currentHp > 0);
}

export function getPlayerUnits(state: CombatState) {
  return getLiveUnits(state).filter((u) => u.isPlayer);
}

export function getEnemyUnits(state: CombatState) {
  return getLiveUnits(state).filter((u) => !u.isPlayer);
}

function posKey(p: Position): string {
  return `${p.x},${p.y}`;
}

function isInBounds(x: number, y: number, w: number, h: number): boolean {
  return x >= 0 && y >= 0 && x < w && y < h;
}

function getNeighbors(pos: Position, includeDiagonal = true): Position[] {
  const dirs = [[0, 1], [0, -1], [1, 0], [-1, 0]];
  if (includeDiagonal) dirs.push([1, 1], [1, -1], [-1, 1], [-1, -1]);
  return dirs.map(([dx, dy]) => ({ x: pos.x + dx, y: pos.y + dy }));
}

export function getDistance(a: Position, b: Position): number {
  return Math.max(Math.abs(a.x - b.x), Math.abs(a.y - b.y)); // Chebyshev (diagonal = 1)
}

// ─── Movement ─────────────────────────────────────────────────────────────────

export function getMovementRange(unit: CombatUnit): number {
  let speed = unit.stats.speed;
  if (hasStatus(unit, 'paralyzed')) speed = Math.floor(speed / 2);
  if (hasStatus(unit, 'metal')) speed = Math.floor(speed / 2);
  if (hasStatus(unit, 'occupied')) speed = Math.floor(speed / 2);
  if (unit.chudActive) speed = 0;
  if (unit.fruitSnacksActive) speed = speed * 2;
  // Meggie silly demeanor
  if (unit.sourceId === 'meggie' && unit.demeanor === 'silly') speed = Math.floor(speed * 1.5);
  return Math.floor(speed / 5); // feet → tiles
}

export function getReachableTiles(unit: CombatUnit, state: CombatState): Position[] {
  const maxTiles = getMovementRange(unit);
  if (maxTiles <= 0) return [];

  const { grid, gridWidth, gridHeight } = state;
  const occupied = new Set(
    getLiveUnits(state)
      .filter((u) => u.unitId !== unit.unitId)
      .map((u) => posKey(u.position))
  );

  const visited = new Map<string, number>();
  const queue: [Position, number][] = [[unit.position, 0]];
  visited.set(posKey(unit.position), 0);
  const reachable: Position[] = [];

  while (queue.length > 0) {
    const [pos, dist] = queue.shift()!;
    if (dist > 0 && !occupied.has(posKey(pos))) reachable.push(pos);
    if (dist >= maxTiles) continue;

    for (const next of getNeighbors(pos)) {
      if (!isInBounds(next.x, next.y, gridWidth, gridHeight)) continue;
      const key = posKey(next);
      if (visited.has(key)) continue;
      if (!grid[next.y][next.x].passable) continue;
      visited.set(key, dist + 1);
      queue.push([next, dist + 1]);
    }
  }

  return reachable;
}

export function getMeleeRange(unit: CombatUnit): Position[] {
  // Adjacent tiles (8-directional)
  return getNeighbors(unit.position).filter(() => true);
}

// ─── Attack Range ─────────────────────────────────────────────────────────────

export function getWeaponRange(unit: CombatUnit): number {
  const def = unit.isPlayer
    ? CHARACTERS[unit.sourceId as CharacterId]
    : ENEMIES[unit.sourceId as EnemyId];
  return def.weapon.rangeInTiles;
}

export function getAttackTargets(attacker: CombatUnit, state: CombatState): CombatUnit[] {
  const range = getWeaponRange(attacker);
  const def = attacker.isPlayer
    ? CHARACTERS[attacker.sourceId as CharacterId]
    : ENEMIES[attacker.sourceId as EnemyId];
  const isAoe = def.weapon.isAoe;

  const enemies = attacker.isPlayer ? getEnemyUnits(state) : getPlayerUnits(state);

  if (isAoe) {
    // AoE hits all in radius around attacker
    const radius = def.weapon.aoeRadiusTiles ?? range;
    return enemies.filter((e) => getDistance(attacker.position, e.position) <= radius);
  }

  return enemies.filter((e) => getDistance(attacker.position, e.position) <= range);
}

// ─── Accuracy ─────────────────────────────────────────────────────────────────

export function calculateHitChance(
  attacker: CombatUnit,
  target: CombatUnit,
  baseAccuracy = 0.9,
  isOpportunityAttack = false
): number {
  let acc = isOpportunityAttack ? 0.9 : baseAccuracy;

  // Attacker modifiers
  if (hasStatus(attacker, 'intimidated')) acc *= 0.75;
  if (hasStatus(attacker, 'confused')) acc *= 0.75;
  if (hasStatus(attacker, 'wet')) acc *= 0.5;
  if (hasStatus(attacker, 'coached')) acc *= 1.25;
  if (hasStatus(attacker, 'invisible')) acc *= 1.25;
  if (attacker.fruitSnacksActive) acc *= 1.25;
  if (attacker.sourceId === 'meggie') {
    if (attacker.demeanor === 'silly' || attacker.demeanor === 'studious') acc *= 1.25;
    if (attacker.fluteSoloTargets?.includes(target.unitId)) acc *= 1.25;
  }

  // Zachy miss tracker
  if (attacker.sourceId === 'zachy' && attacker.zachyMissTracker?.[target.unitId]) {
    acc *= 1 + attacker.zachyMissTracker[target.unitId].accuracyBonus;
  }

  // Target modifiers
  if (hasStatus(target, 'dodge' as StatusEffectId)) acc *= 0.6; // handled via buff
  if (hasStatus(target, 'occupied')) acc *= 1.25;
  if (hasStatus(target, 'invisible')) return 0;

  // Zachy passive: attacks against Zachy/allies in 10ft are 40% less likely
  if (!attacker.isPlayer && target.sourceId === 'zachy') acc *= 0.6;

  // Why Why passive: weapon attacks at 80% accuracy
  if (!attacker.isPlayer && target.sourceId === 'whyWhy') acc *= 0.8;

  return Math.max(0, Math.min(1, acc));
}

export function rollHit(accuracy: number): boolean {
  return Math.random() < accuracy;
}

export function rollCrit(): boolean {
  return Math.random() < 0.001; // 1/1000
}

// ─── Damage ───────────────────────────────────────────────────────────────────

export function calculateWeaponDamage(
  attacker: CombatUnit,
  target: CombatUnit,
  isCrit = false
): number {
  let dmg = Math.max(1, attacker.stats.attack - Math.floor(target.stats.defense * 0.5));

  // Attacker bonuses
  if (isCrit) dmg *= 2;
  if (hasStatus(attacker, 'coached')) dmg *= 1.25;
  if (hasStatus(attacker, 'invisible')) dmg *= 1.25;
  if (hasStatus(attacker, 'intimidated')) dmg *= 0.75;
  if (hasStatus(attacker, 'burned')) dmg *= 0.5;
  if (hasStatus(attacker, 'ragebaited')) dmg *= 1.25;
  if (attacker.fruitSnacksActive) dmg *= 1.25;
  if (attacker.sourceId === 'meggie') {
    if (attacker.demeanor === 'intimidating' || attacker.demeanor === 'studious') dmg *= 1.25;
    if (attacker.fluteSoloTargets?.includes(target.unitId)) dmg *= 1.25;
  }
  if (attacker.sourceId === 'zachy' && attacker.zachyMissTracker?.[target.unitId]) {
    dmg *= 1 + attacker.zachyMissTracker[target.unitId].damageBonus;
  }

  // Kevin blitz first attack
  if (attacker.sourceId === 'kevin' && !attacker.blitzUsed) dmg *= 1.3;

  // Root in place
  const rootBuff = attacker.combatBuffs.find((b) => b.id === 'rootInPlace');
  if (rootBuff) dmg *= 1.5;

  // Target damage reduction
  if (hasStatus(target, 'metal')) dmg *= 0.5;
  if (hasStatus(target, 'bruised')) dmg *= 1.5;
  if (target.sourceId === 'whyWhy' && !target.isPlayer === false) dmg *= 0.75; // Teary Eyes
  if (!attacker.isPlayer && target.sourceId === 'whyWhy') dmg *= 0.75;

  // Shelly shell shield passive
  if (target.sourceId === 'shelly') dmg *= 0.75;

  // Burned: if < 1 dmg after halving, return 0 (attack misses)
  if (hasStatus(attacker, 'burned') && dmg < 1) return 0;

  return Math.max(1, Math.round(dmg));
}

// ─── Apply Damage to Unit ─────────────────────────────────────────────────────

export function applyDamageToUnit(unit: CombatUnit, amount: number): CombatUnit {
  return { ...unit, currentHp: Math.max(0, unit.currentHp - amount) };
}

export function healUnit(unit: CombatUnit, amount: number): CombatUnit {
  return { ...unit, currentHp: Math.min(unit.stats.maxHp, unit.currentHp + amount) };
}

// ─── Update unit in state ─────────────────────────────────────────────────────

export function updateUnit(state: CombatState, updated: CombatUnit): CombatState {
  return {
    ...state,
    units: state.units.map((u) => (u.unitId === updated.unitId ? updated : u)),
  };
}

export function updateUnits(state: CombatState, updates: CombatUnit[]): CombatState {
  const map = new Map(updates.map((u) => [u.unitId, u]));
  return { ...state, units: state.units.map((u) => map.get(u.unitId) ?? u) };
}

export function addLog(
  state: CombatState,
  message: string,
  type: CombatLogEntry['type'] = 'system'
): CombatState {
  const entry: CombatLogEntry = {
    id: `log_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
    message,
    type,
    createdAt: Date.now(),
  };
  return { ...state, log: [entry, ...state.log].slice(0, 50) };
}

export function addDmgNumber(state: CombatState, dmg: DamageNumber): CombatState {
  return { ...state, damageNumbers: [...state.damageNumbers, dmg] };
}

export function clearOldDamageNumbers(state: CombatState): CombatState {
  const cutoff = Date.now() - 2000;
  return { ...state, damageNumbers: state.damageNumbers.filter((d) => d.createdAt > cutoff) };
}

// ─── Execute Weapon Attack ────────────────────────────────────────────────────

export function executeWeaponAttack(
  attackerId: string,
  targetId: string,
  state: CombatState,
  isOpportunity = false
): CombatState {
  let s = { ...state };
  const attacker = getUnit(s, attackerId);
  let target = getUnit(s, targetId);
  if (!attacker || !target || target.currentHp <= 0) return s;

  // Paralysis check for attacker
  if (hasStatus(attacker, 'paralyzed') && Math.random() < 1 / 3) {
    s = addLog(s, `${attacker.name} is paralyzed and couldn't attack!`, 'status');
    return s;
  }

  // Confused — random direction movement handled elsewhere; attacks are -25% acc
  // Ragebaited — 1/4 chance hit ally/self
  let actualTargetId = targetId;
  if (hasStatus(attacker, 'ragebaited') && Math.random() < 0.25) {
    const ownTeam = attacker.isPlayer
      ? getPlayerUnits(s).filter((u) => u.unitId !== attackerId)
      : getEnemyUnits(s).filter((u) => u.unitId !== attackerId);
    if (ownTeam.length > 0) {
      actualTargetId = ownTeam[Math.floor(Math.random() * ownTeam.length)].unitId;
      s = addLog(s, `${attacker.name} is ragebaited and attacks ${getUnit(s, actualTargetId)?.name ?? 'an ally'}!`, 'status');
    }
  }

  target = getUnit(s, actualTargetId)!;
  if (!target) return s;

  const acc = calculateHitChance(attacker, target, 0.9, isOpportunity);
  const hit = rollHit(acc);

  if (!hit) {
    s = addLog(s, `${attacker.name} missed ${target.name}!`, 'attack');
    s = addDmgNumber(s, makeDamageNumber('MISS', target.position.x, target.position.y, 'miss'));

    // Zachy passive: miss against Zachy grants permanent bonus
    if (!attacker.isPlayer && target.sourceId === 'zachy') {
      const zachy = getUnit(s, target.unitId)!;
      const tracker = { ...(zachy.zachyMissTracker ?? {}) };
      const current = tracker[attackerId] ?? { accuracyBonus: 0, damageBonus: 0 };
      tracker[attackerId] = {
        accuracyBonus: current.accuracyBonus + 0.25,
        damageBonus: current.damageBonus + 0.25,
      };
      s = updateUnit(s, { ...zachy, zachyMissTracker: tracker });
    }

    return s;
  }

  const isCrit = rollCrit();
  const dmg = calculateWeaponDamage(attacker, target, isCrit);

  if (dmg <= 0) {
    s = addLog(s, `${attacker.name}'s attack fizzles against ${target.name}!`, 'attack');
    return s;
  }

  let updatedTarget = applyDamageToUnit(target, dmg);

  // Kevin blitz used
  if (attacker.sourceId === 'kevin' && !attacker.blitzUsed) {
    s = updateUnit(s, { ...attacker, blitzUsed: true });
  }

  // Apply weapon-specific effects
  switch (attacker.sourceId) {
    case 'granty': {
      // Suspicious Sock: 45% Poisoned, 30% Badly Poisoned
      const roll = Math.random();
      if (roll < 0.3) updatedTarget = addStatus(updatedTarget, 'badlyPoisoned');
      else if (roll < 0.75) updatedTarget = addStatus(updatedTarget, 'poisoned');
      break;
    }
    case 'davy': {
      // Loud Keyboard: 60% Occupied
      if (Math.random() < 0.6) updatedTarget = addStatus(updatedTarget, 'occupied', 2);
      break;
    }
    case 'meggie': {
      // Tennis Racket: 50% Bruised
      if (Math.random() < 0.5) updatedTarget = addStatus(updatedTarget, 'bruised', 3);
      break;
    }
    case 'whyWhy': {
      // Pillow Chuck: push back 2 tiles, -25% damage buff on target
      updatedTarget = {
        ...updatedTarget,
        combatBuffs: [
          ...updatedTarget.combatBuffs.filter((b) => b.id !== 'pillowDebuff'),
          { id: 'pillowDebuff', name: '-25% Damage', description: 'Doing 25% less damage until end of next turn.', color: '#fde68a', isBuff: false },
        ],
      };
      // Push back handled by caller
      break;
    }
    case 'aquaGloop': {
      if (Math.random() < 0.3) updatedTarget = addStatus(updatedTarget, 'wet', 3);
      break;
    }
    case 'lakeLurker': {
      if (Math.random() < 0.5) updatedTarget = addStatus(updatedTarget, 'wet', 3);
      break;
    }
    case 'shoreCrawler': {
      if (Math.random() < 0.4) updatedTarget = addStatus(updatedTarget, 'bruised', 3);
      break;
    }
  }

  // Meggie intimidating demeanor: attacker who hits Meggie gets Intimidated
  if (target.sourceId === 'meggie' && target.demeanor === 'intimidating' && !attacker.isPlayer) {
    if (Math.random() < 0.5) {
      const updatedAttacker = addStatus(getUnit(s, attacker.unitId)!, 'intimidated', 3);
      s = updateUnit(s, updatedAttacker);
      s = addLog(s, `${attacker.name} is intimidated by Meggie!`, 'status');
    }
  }

  // Davy passive: trigger Ragebaited on attacker when Davy is attacked
  if (!attacker.isPlayer && target.sourceId === 'davy') {
    const updatedAttacker = addStatus(getUnit(s, attacker.unitId)!, 'ragebaited');
    s = updateUnit(s, updatedAttacker);
  }

  const critText = isCrit ? ' CRITICAL HIT!' : '';
  s = addLog(s, `${attacker.name} hits ${target.name} for ${dmg} damage!${critText}`, 'attack');
  s = addDmgNumber(
    s,
    makeDamageNumber(
      isCrit ? `CRIT! ${dmg}` : dmg,
      target.position.x,
      target.position.y,
      isCrit ? 'critical' : 'damage'
    )
  );

  s = { ...s, isShaking: true };
  setTimeout(() => {/* isShaking cleared by UI */ }, 300);

  if (updatedTarget.currentHp <= 0) {
    s = addLog(s, `${target.name} has been defeated!`, 'death');
  }

  s = updateUnit(s, updatedTarget);
  return s;
}

// ─── Start of Turn ────────────────────────────────────────────────────────────

export function processStartOfTurn(unitId: string, state: CombatState): CombatState {
  let s = { ...state };
  const unit = getUnit(s, unitId);
  if (!unit || unit.currentHp <= 0) return s;

  const { unit: ticked, dotDamage, log } = tickStatusEffects(unit);
  for (const msg of log) s = addLog(s, msg, 'status');
  s = updateUnit(s, ticked);

  if (dotDamage > 0) {
    s = addDmgNumber(s, makeDamageNumber(dotDamage, unit.position.x, unit.position.y, 'damage'));
  }

  // Reset per-turn tracking
  const refreshed = getUnit(s, unitId)!;
  s = updateUnit(s, {
    ...refreshed,
    actionsUsed: { moved: false, attacked: false, ability: false, reaction: false },
    blitzUsed: false,
  });

  return s;
}

// ─── Enemy AI ─────────────────────────────────────────────────────────────────

export function runEnemyTurn(enemyId: string, state: CombatState): CombatState {
  let s = state;
  const enemy = getUnit(s, enemyId);
  if (!enemy || enemy.currentHp <= 0) return s;

  s = processStartOfTurn(enemyId, s);
  const refreshed = getUnit(s, enemyId);
  if (!refreshed || refreshed.currentHp <= 0) return s;

  const players = getPlayerUnits(s);
  if (players.length === 0) return s;

  // AI logic based on enemy type
  const def = ENEMIES[enemy.sourceId as EnemyId];

  if (def.aiType === 'support' && enemy.sourceId === 'shelly') {
    s = runShellyAI(enemyId, s);
  } else if (enemy.sourceId === 'kevin') {
    s = runKevinAI(enemyId, s);
  } else {
    s = runBasicEnemyAI(enemyId, s);
  }

  return s;
}

function runBasicEnemyAI(enemyId: string, state: CombatState): CombatState {
  let s = state;
  const enemy = getUnit(s, enemyId)!;
  const players = getPlayerUnits(s);

  // Find closest player
  const target = players.reduce((closest, p) =>
    getDistance(enemy.position, p.position) < getDistance(enemy.position, closest.position)
      ? p
      : closest
  );

  // Move towards target if not in range
  const range = getWeaponRange(enemy);
  const dist = getDistance(enemy.position, target.position);

  if (dist > range) {
    const reachable = getReachableTiles(enemy, s);
    if (reachable.length > 0) {
      const best = reachable.reduce((b, p) =>
        getDistance(p, target.position) < getDistance(b, target.position) ? p : b
      );
      const updatedEnemy = { ...enemy, position: best, actionsUsed: { ...enemy.actionsUsed, moved: true } };
      s = updateUnit(s, updatedEnemy);
    }
  }

  // Attack if in range
  const updatedEnemy = getUnit(s, enemyId)!;
  const targets = getAttackTargets(updatedEnemy, s);
  if (targets.length > 0 && !updatedEnemy.actionsUsed.attacked) {
    const weakest = targets.reduce((w, t) => (t.currentHp < w.currentHp ? t : w));
    s = executeWeaponAttack(enemyId, weakest.unitId, s);
    const postAttack = getUnit(s, enemyId)!;
    s = updateUnit(s, { ...postAttack, actionsUsed: { ...postAttack.actionsUsed, attacked: true } });
  }

  return s;
}

function runKevinAI(kevinId: string, state: CombatState): CombatState {
  let s = state;
  const kevin = getUnit(s, kevinId)!;
  const players = getPlayerUnits(s);

  // Kevin rushes the weakest player
  const target = players.reduce((w, p) => (p.currentHp < w.currentHp ? p : w));

  // Move aggressively
  const reachable = getReachableTiles(kevin, s);
  if (reachable.length > 0) {
    const best = reachable.reduce((b, p) =>
      getDistance(p, target.position) < getDistance(b, target.position) ? p : b
    );
    s = updateUnit(s, { ...kevin, position: best, actionsUsed: { ...kevin.actionsUsed, moved: true } });
  }

  // Try to attack
  const updatedKevin = getUnit(s, kevinId)!;
  const targets = getAttackTargets(updatedKevin, s);
  if (targets.length > 0) {
    const weakest = targets.reduce((w, t) => (t.currentHp < w.currentHp ? t : w));
    s = executeWeaponAttack(kevinId, weakest.unitId, s);
    const postAttack = getUnit(s, kevinId)!;
    s = updateUnit(s, { ...postAttack, actionsUsed: { ...postAttack.actionsUsed, attacked: true } });

    // Double Strike: Kevin gets two attacks
    const updatedAgain = getUnit(s, kevinId)!;
    const nextTargets = getAttackTargets(updatedAgain, s);
    if (nextTargets.length > 0 && !updatedAgain.actionsUsed.ability) {
      const pick = nextTargets[Math.floor(Math.random() * nextTargets.length)];
      s = executeWeaponAttack(kevinId, pick.unitId, s);
      const final = getUnit(s, kevinId)!;
      s = updateUnit(s, { ...final, actionsUsed: { ...final.actionsUsed, ability: true } });
    }
  }

  return s;
}

function runShellyAI(shellyId: string, state: CombatState): CombatState {
  let s = state;
  const shelly = getUnit(s, shellyId)!;
  const kevinUnit = getEnemyUnits(s).find((u) => u.sourceId === 'kevin');

  // Heal Kevin if he's below 50% HP
  if (kevinUnit && kevinUnit.currentHp < kevinUnit.stats.maxHp * 0.5 && !shelly.actionsUsed.ability) {
    const heal = Math.floor(kevinUnit.stats.maxHp * 0.2);
    const healed = healUnit(kevinUnit, heal);
    const withCoached = addStatus(healed, 'coached', 3);
    s = updateUnit(s, withCoached);
    s = addLog(s, `Shelly supports Kevin! Kevin heals ${heal} HP and gains Coached!`, 'ability');
    s = addDmgNumber(s, makeDamageNumber(heal, kevinUnit.position.x, kevinUnit.position.y, 'heal'));
    s = updateUnit(s, { ...shelly, actionsUsed: { ...shelly.actionsUsed, ability: true } });
  }

  // Move toward players
  const players = getPlayerUnits(s);
  if (players.length === 0) return s;
  const target = players[Math.floor(Math.random() * players.length)];
  const reachable = getReachableTiles(shelly, s);
  if (reachable.length > 0 && !shelly.actionsUsed.moved) {
    const best = reachable.reduce((b, p) =>
      getDistance(p, target.position) < getDistance(b, target.position) ? p : b
    );
    s = updateUnit(s, { ...shelly, position: best, actionsUsed: { ...shelly.actionsUsed, moved: true } });
  }

  // Attack if adjacent
  const updatedShelly = getUnit(s, shellyId)!;
  const targets = getAttackTargets(updatedShelly, s);
  if (targets.length > 0 && !updatedShelly.actionsUsed.attacked) {
    s = executeWeaponAttack(shellyId, targets[0].unitId, s);
    const post = getUnit(s, shellyId)!;
    s = updateUnit(s, { ...post, actionsUsed: { ...post.actionsUsed, attacked: true } });
  }

  return s;
}

// ─── Turn Advancement ─────────────────────────────────────────────────────────

export function advanceTurn(state: CombatState): CombatState {
  const liveIds = new Set(getLiveUnits(state).map((u) => u.unitId));
  const validOrder = state.turnOrder.filter((id) => liveIds.has(id));
  if (validOrder.length === 0) return state;

  const nextIndex = (state.currentTurnIndex + 1) % validOrder.length;
  const nextUnitId = validOrder[nextIndex];

  // Determine phase
  const nextUnit = getUnit(state, nextUnitId);
  const phase: CombatState['phase'] = nextUnit?.isPlayer ? 'player_turn' : 'enemy_turn';

  return {
    ...state,
    turnOrder: validOrder,
    currentTurnIndex: nextIndex,
    activeUnitId: nextUnitId,
    phase,
    selectedAction: 'none',
    highlightedTiles: [],
    targetTiles: [],
    isShaking: false,
    turnCount: state.turnCount + 1,
  };
}

// ─── Win Condition ────────────────────────────────────────────────────────────

export function checkCombatEnd(state: CombatState): 'ongoing' | 'victory' | 'defeat' {
  const players = getPlayerUnits(state);
  const enemies = getEnemyUnits(state);
  if (players.length === 0) return 'defeat';
  if (enemies.length === 0) return 'victory';
  return 'ongoing';
}

// ─── Execute Active Ability ───────────────────────────────────────────────────

export function executeZachyOrb(
  casterId: string,
  targetIds: string[],
  statusId: StatusEffectId,
  state: CombatState
): CombatState {
  let s = state;
  const caster = getUnit(s, casterId)!;
  const totalTargets = targetIds.length || 1;

  for (const targetId of targetIds) {
    const target = getUnit(s, targetId);
    if (!target || target.currentHp <= 0) continue;
    const dmg = Math.max(1, Math.round((target.stats.maxHp * 0.15) / totalTargets));
    let updated = applyDamageToUnit(target, dmg);
    updated = addStatus(updated, statusId, 5);
    s = updateUnit(s, updated);
    s = addLog(s, `Magical Orb hits ${target.name} for ${dmg} and applies ${STATUS_EFFECTS[statusId].name}!`, 'ability');
    s = addDmgNumber(s, makeDamageNumber(dmg, target.position.x, target.position.y, 'damage'));
  }

  s = updateUnit(s, { ...caster, actionsUsed: { ...caster.actionsUsed, ability: true } });
  return s;
}

export function executeMeggieFluteSOlo(casterId: string, state: CombatState): CombatState {
  let s = state;
  const caster = getUnit(s, casterId)!;
  const enemies = getEnemyUnits(s);
  const range = 12;
  const inRange = enemies.filter((e) => getDistance(caster.position, e.position) <= range);
  const affected: string[] = [];

  for (const enemy of inRange) {
    if (Math.random() < 0.6) {
      const updated = addStatus(enemy, 'confused', 3);
      s = updateUnit(s, updated);
      s = addLog(s, `${enemy.name} is confused by Meggie's flute solo!`, 'status');
      affected.push(enemy.unitId);
    }
  }

  const updated = getUnit(s, casterId)!;
  s = updateUnit(s, { ...updated, fluteSoloTargets: [...(updated.fluteSoloTargets ?? []), ...affected], actionsUsed: { ...updated.actionsUsed, ability: true } });
  s = addLog(s, `Meggie plays a magnificent flute solo!`, 'ability');
  return s;
}
