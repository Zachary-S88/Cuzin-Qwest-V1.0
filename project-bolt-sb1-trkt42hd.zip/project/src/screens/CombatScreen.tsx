import React, { useEffect, useRef } from 'react';
import { useGame } from '../contexts/GameContext';
import type { CombatUnit } from '../game/types';
import { getUnit } from '../game/combatEngine';
import CharacterToken from '../components/CharacterToken';
import StatusBadges from '../components/StatusBadges';
import FloatingDamage from '../components/FloatingDamage';
import TurnOrderBar from '../components/TurnOrderBar';
import ActionPanel from '../components/ActionPanel';

const TILE_SIZE = 52;

const TILE_COLORS: Record<string, string> = {
  water: '#1d4ed8',
  shallowWater: '#3b82f6',
  grass: '#16a34a',
  path: '#a16207',
  stone: '#6b7280',
  sand: '#d97706',
  lilyPad: '#15803d',
  tree: '#166534',
  fortressWall: '#374151',
  fortressFloor: '#4b5563',
};

const TILE_TEXTURE: Record<string, string> = {
  lilyPad: '🌿',
  tree: '🌲',
  fortressWall: '🧱',
};

export default function CombatScreen() {
  const { state, dispatch } = useGame();
  const cs = state.combatState;
  const containerRef = useRef<HTMLDivElement>(null);
  const shakeTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const enemyTurnTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Clear damage numbers periodically
  useEffect(() => {
    const interval = setInterval(() => {
      dispatch({ type: 'COMBAT_CLEAR_DAMAGE_NUMBERS' });
    }, 2500);
    return () => clearInterval(interval);
  }, [dispatch]);

  // Stop screen shake
  useEffect(() => {
    if (cs?.isShaking) {
      if (shakeTimerRef.current) clearTimeout(shakeTimerRef.current);
      shakeTimerRef.current = setTimeout(() => {
        dispatch({ type: 'COMBAT_STOP_SHAKE' });
      }, 400);
    }
  }, [cs?.isShaking, dispatch]);

  // Trigger enemy turn after a short delay
  useEffect(() => {
    if (cs?.phase === 'enemy_turn' && cs.activeUnitId) {
      if (enemyTurnTimerRef.current) clearTimeout(enemyTurnTimerRef.current);
      enemyTurnTimerRef.current = setTimeout(() => {
        dispatch({ type: 'COMBAT_ENEMY_TURN_DONE' });
      }, 900);
    }
    return () => {
      if (enemyTurnTimerRef.current) clearTimeout(enemyTurnTimerRef.current);
    };
  }, [cs?.phase, cs?.activeUnitId, cs?.turnCount, dispatch]);

  if (!cs) return null;

  const activeUnit = cs.activeUnitId ? getUnit(cs, cs.activeUnitId) : null;
  const tileSize = TILE_SIZE;

  function handleTileClick(x: number, y: number) {
    if (!activeUnit || cs!.phase !== 'player_turn') return;
    if (cs!.selectedAction === 'move') {
      const reachable = cs!.highlightedTiles;
      const isReachable = reachable.some((t) => t.x === x && t.y === y);
      if (isReachable) {
        dispatch({ type: 'COMBAT_MOVE', targetX: x, targetY: y });
      }
    }
  }

  function handleUnitClick(unit: CombatUnit) {
    if (!activeUnit || cs!.phase !== 'player_turn') return;
    if (cs!.selectedAction === 'attack') {
      const targets = cs!.targetTiles;
      const isTarget = targets.some((t) => t.x === unit.position.x && t.y === unit.position.y);
      if (isTarget && !unit.isPlayer) {
        // Why Why target selection for "Why?" ability
        if (activeUnit.sourceId === 'whyWhy' && activeUnit.actionsUsed.ability === false) {
          // Still use attack action
          dispatch({ type: 'COMBAT_ATTACK', targetId: unit.unitId });
        } else {
          dispatch({ type: 'COMBAT_ATTACK', targetId: unit.unitId });
        }
      }
    }
  }

  // Victory / Defeat overlays
  if (cs.phase === 'victory') {
    return <VictoryScreen />;
  }
  if (cs.phase === 'defeat') {
    return <DefeatScreen />;
  }

  const isMeggieNeedsDemeanor = activeUnit?.sourceId === 'meggie' && activeUnit.demeanor === undefined;

  return (
    <div className="fixed inset-0 flex flex-col bg-gray-950 overflow-hidden">
      {/* Turn Order Bar */}
      <div className="bg-gray-900 border-b border-gray-700 shrink-0">
        <TurnOrderBar
          turnOrder={cs.turnOrder}
          units={cs.units}
          activeUnitId={cs.activeUnitId}
          turnCount={cs.turnCount}
        />
      </div>

      {/* Enemy turn indicator */}
      {cs.phase === 'enemy_turn' && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 z-20 bg-red-600/90 text-white px-4 py-1.5 rounded-full text-sm font-black animate-pulse shadow-lg shadow-red-600/30">
          ⚡ {activeUnit?.name ?? 'Enemy'}'s Turn...
        </div>
      )}

      {/* Combat Grid */}
      <div
        ref={containerRef}
        className={`flex-1 overflow-auto ${cs.isShaking ? 'animate-shake' : ''}`}
      >
        <div
          className="relative mx-auto mt-2"
          style={{ width: cs.gridWidth * tileSize, height: cs.gridHeight * tileSize }}
        >
          {/* Tiles */}
          {cs.grid.map((row, y) =>
            row.map((tile, x) => {
              const isHighlighted = cs.highlightedTiles.some((h) => h.x === x && h.y === y);
              const isTarget = cs.targetTiles.some((t) => t.x === x && t.y === y);
              const color = TILE_COLORS[tile.type] ?? '#1d4ed8';
              return (
                <div
                  key={`${x},${y}`}
                  className={`absolute border border-black/20 cursor-pointer transition-all duration-100 flex items-center justify-center ${
                    isHighlighted ? 'ring-2 ring-cyan-400 ring-inset brightness-125 z-10' :
                    isTarget ? 'ring-2 ring-red-400 ring-inset brightness-125 z-10' : ''
                  }`}
                  style={{
                    left: x * tileSize,
                    top: y * tileSize,
                    width: tileSize,
                    height: tileSize,
                    backgroundColor: isHighlighted ? `${color}` : isTarget ? `${color}` : color,
                    filter: isHighlighted ? 'brightness(1.3)' : isTarget ? 'brightness(1.4) hue-rotate(330deg)' : undefined,
                  }}
                  onClick={() => handleTileClick(x, y)}
                >
                  {TILE_TEXTURE[tile.type] && (
                    <span style={{ fontSize: 18, pointerEvents: 'none' }}>{TILE_TEXTURE[tile.type]}</span>
                  )}
                  {/* Grid coords (hidden but helps debug) */}
                </div>
              );
            })
          )}

          {/* Units */}
          {cs.units.map((unit) => {
            if (unit.currentHp <= 0) return null;
            const isActive = unit.unitId === cs.activeUnitId;
            const isTargetable = cs.selectedAction === 'attack' && cs.targetTiles.some(t => t.x === unit.position.x && t.y === unit.position.y);
            return (
              <div
                key={unit.unitId}
                className={`absolute z-20 flex flex-col items-center cursor-pointer transition-all duration-300 ${isTargetable ? 'animate-pulse' : ''}`}
                style={{
                  left: unit.position.x * tileSize,
                  top: unit.position.y * tileSize,
                  width: tileSize,
                  transition: 'left 0.25s ease-in-out, top 0.25s ease-in-out',
                }}
                onClick={() => handleUnitClick(unit)}
              >
                {isTargetable && (
                  <div className="absolute inset-0 rounded-full ring-2 ring-red-400 animate-pulse z-30" />
                )}
                <CharacterToken
                  sourceId={unit.sourceId}
                  name={unit.name}
                  color={unit.color}
                  emoji={unit.emoji}
                  currentHp={unit.currentHp}
                  maxHp={unit.stats.maxHp}
                  isActive={isActive}
                  isDead={unit.currentHp <= 0}
                  isEnemy={!unit.isPlayer}
                  size="sm"
                />
                <StatusBadges effects={unit.statusEffects} buffs={unit.combatBuffs} />
              </div>
            );
          })}

          {/* Floating Damage Numbers */}
          <FloatingDamage numbers={cs.damageNumbers} tileSize={tileSize} />
        </div>
      </div>

      {/* Combat Log (mini) */}
      <div className="shrink-0 bg-gray-900/80 px-3 py-1 border-t border-gray-800 max-h-12 overflow-hidden">
        {cs.log.slice(0, 2).map((entry) => (
          <div key={entry.id} className={`text-xs truncate ${
            entry.type === 'death' ? 'text-red-400' :
            entry.type === 'ability' ? 'text-yellow-400' :
            entry.type === 'status' ? 'text-purple-400' :
            'text-gray-400'
          }`}>
            {entry.message}
          </div>
        ))}
      </div>

      {/* Action Panel — only show for player turns */}
      {cs.phase === 'player_turn' && activeUnit?.isPlayer && (
        <ActionPanel activeUnit={activeUnit} isMeggieNeedsDemeanor={isMeggieNeedsDemeanor} />
      )}
    </div>
  );
}

function VictoryScreen() {
  const { state, dispatch } = useGame();
  const isBoss = state.combatState?.isBossFight;

  useEffect(() => {
    if (!isBoss) {
      // Give XP and return to exploration after a brief delay
      const timer = setTimeout(() => {
        if (state.pendingCombat?.triggerInstanceId) {
          dispatch({ type: 'DEFEAT_MAP_ENEMY', instanceId: state.pendingCombat.triggerInstanceId });
        } else {
          dispatch({ type: 'NAVIGATE', screen: 'exploration' });
        }
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [isBoss, state.pendingCombat?.triggerInstanceId, dispatch]);

  if (isBoss) {
    return (
      <div
        className="fixed inset-0 flex flex-col items-center justify-center"
        style={{ background: 'radial-gradient(ellipse, #1d4ed8 0%, #0a1628 80%)' }}
      >
        <div className="text-6xl animate-bounce mb-4">🏆</div>
        <h1 className="text-white font-black text-3xl mb-2" style={{ fontFamily: 'Nunito, sans-serif' }}>
          Victory!
        </h1>
        <p className="text-blue-300 text-base mb-8">You defeated Shelly and Kevin!</p>
        <button
          onClick={() => dispatch({ type: 'NAVIGATE', screen: 'bossChoice' })}
          className="px-8 py-4 bg-yellow-500 hover:bg-yellow-400 text-gray-900 font-black text-lg rounded-2xl transition-all active:scale-95 shadow-2xl shadow-yellow-500/30"
        >
          Choose a Cuzin to Rescue →
        </button>
      </div>
    );
  }

  return (
    <div
      className="fixed inset-0 flex flex-col items-center justify-center"
      style={{ background: 'radial-gradient(ellipse, #166534 0%, #0a1628 80%)' }}
    >
      <div className="text-5xl animate-bounce mb-3">⚔️</div>
      <h1 className="text-white font-black text-2xl mb-1">Victory!</h1>
      <p className="text-green-300 text-sm">Returning to exploration...</p>
    </div>
  );
}

function DefeatScreen() {
  const { dispatch } = useGame();
  return (
    <div
      className="fixed inset-0 flex flex-col items-center justify-center"
      style={{ background: 'radial-gradient(ellipse, #450a0a 0%, #0a0a0a 80%)' }}
    >
      <div className="text-6xl mb-4">💀</div>
      <h1 className="text-red-400 font-black text-3xl mb-2" style={{ fontFamily: 'Nunito, sans-serif' }}>
        Defeated!
      </h1>
      <p className="text-gray-400 text-base mb-8">The Cuzins have fallen...</p>
      <div className="flex gap-3">
        <button
          onClick={() => dispatch({ type: 'NAVIGATE', screen: 'hub' })}
          className="px-6 py-3 bg-gray-700 hover:bg-gray-600 text-white font-bold rounded-xl transition-all active:scale-95"
        >
          Return to Hub
        </button>
        <button
          onClick={() => dispatch({ type: 'NAVIGATE', screen: 'title' })}
          className="px-6 py-3 bg-red-700 hover:bg-red-600 text-white font-bold rounded-xl transition-all active:scale-95"
        >
          Title Screen
        </button>
      </div>
    </div>
  );
}
