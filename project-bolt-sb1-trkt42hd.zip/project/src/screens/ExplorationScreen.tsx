import React, { useEffect, useRef, useCallback } from 'react';
import { useGame } from '../contexts/GameContext';
import { getLakeTileType, LAKE_MAP } from '../game/maps';
import { ENEMIES } from '../game/characters';

const TILE_SIZE = 36;

const TILE_COLORS: Record<string, string> = {
  water: '#1d4ed8',
  shallowWater: '#3b82f6',
  grass: '#16a34a',
  fortress: '#6b7280',
  fortressWall: '#374151',
};

const TILE_EMOJI: Record<string, string> = {
  fortress: '🏰',
};

export default function ExplorationScreen() {
  const { state, dispatch } = useGame();
  const { explorationState } = state;
  const { playerPosition, enemies } = explorationState;
  const canvasRef = useRef<HTMLDivElement>(null);
  const keysRef = useRef<Set<string>>(new Set());
  const moveTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const tryMove = useCallback(
    (dx: number, dy: number) => {
      const nx = playerPosition.x + dx;
      const ny = playerPosition.y + dy;
      if (nx < 0 || ny < 0 || nx >= LAKE_MAP.width || ny >= LAKE_MAP.height) return;
      const tile = getLakeTileType(nx, ny);
      if (tile === 'fortressWall') return;

      // Check for enemy collision (non-boss only — boss triggers after 3 fortress steps)
      const nearby = enemies.find(
        (e) => !e.defeated && !e.isBoss && Math.abs(e.position.x - nx) <= 1 && Math.abs(e.position.y - ny) <= 1
      );

      if (nearby) {
        dispatch({
          type: 'START_COMBAT',
          enemyIds: [nearby.enemyId],
          enemyLevels: [nearby.level],
          environment: 'lake',
          isBoss: false,
          triggerInstanceId: nearby.instanceId,
        });
        return;
      }

      dispatch({ type: 'MOVE_PLAYER', x: nx, y: ny });

      // After moving, check if this was the 3rd fortress step → trigger boss
      const destTile = getLakeTileType(nx, ny);
      if (destTile === 'fortress') {
        const prevTile = getLakeTileType(playerPosition.x, playerPosition.y);
        const steppingOntoFortress = prevTile !== 'fortress';
        const newStepCount = steppingOntoFortress ? explorationState.fortressStepsTaken + 1 : explorationState.fortressStepsTaken;
        if (newStepCount >= 3) {
          const boss = enemies.find((e) => e.isBoss && !e.defeated);
          if (boss) {
            dispatch({
              type: 'START_COMBAT',
              enemyIds: ['shelly', 'kevin'],
              enemyLevels: [5, 5],
              environment: 'fortress',
              isBoss: true,
              triggerInstanceId: boss.instanceId,
            });
          }
        }
      }
    },
    [playerPosition, enemies, dispatch, explorationState.fortressStepsTaken]
  );

  // Keyboard control
  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      keysRef.current.add(e.key);
    }
    function onKeyUp(e: KeyboardEvent) {
      keysRef.current.delete(e.key);
    }
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);

    moveTimerRef.current = setInterval(() => {
      const keys = keysRef.current;
      const dx = keys.has('ArrowRight') || keys.has('d') || keys.has('D') ? 1 : keys.has('ArrowLeft') || keys.has('a') || keys.has('A') ? -1 : 0;
      const dy = keys.has('ArrowDown') || keys.has('s') || keys.has('S') ? 1 : keys.has('ArrowUp') || keys.has('w') || keys.has('W') ? -1 : 0;
      if (dx !== 0 || dy !== 0) tryMove(dx, dy);
    }, 200);

    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      if (moveTimerRef.current) clearInterval(moveTimerRef.current);
    };
  }, [tryMove]);

  // Camera offset to center player
  const camX = Math.max(0, playerPosition.x - 8);
  const camY = Math.max(0, playerPosition.y - 5);
  const visibleW = 18;
  const visibleH = 12;

  return (
    <div
      className="fixed inset-0 overflow-hidden"
      style={{ background: '#0d2137' }}
    >
      {/* HUD top bar */}
      <div className="absolute top-0 left-0 right-0 z-10 flex items-center justify-between px-4 py-2 bg-black/50 backdrop-blur-sm border-b border-gray-700">
        <button
          onClick={() => dispatch({ type: 'NAVIGATE', screen: 'hub' })}
          className="px-3 py-1 bg-gray-700 hover:bg-gray-600 text-white text-sm rounded-lg font-bold transition-all active:scale-95"
        >
          ← Hub
        </button>
        <div className="text-white font-black text-sm">🌊 Lake Region</div>
        <div className="text-gray-400 text-xs flex items-center gap-2">
          {enemies.filter((e) => !e.defeated && !e.isBoss).length} enemies left
          {explorationState.fortressStepsTaken > 0 && !state.storyFlags.bossDefeated && (
            <span className="text-red-400 font-bold">
              ⚡ Fortress: {explorationState.fortressStepsTaken}/3
            </span>
          )}
        </div>
      </div>

      {/* Map */}
      <div
        className="absolute"
        style={{ top: 48, left: 0, right: 0, bottom: 80 }}
      >
        <div
          ref={canvasRef}
          className="relative"
          style={{ width: visibleW * TILE_SIZE, height: visibleH * TILE_SIZE, margin: '0 auto' }}
        >
          {Array.from({ length: visibleH }).map((_, row) =>
            Array.from({ length: visibleW }).map((_, col) => {
              const mapX = camX + col;
              const mapY = camY + row;
              if (mapX >= LAKE_MAP.width || mapY >= LAKE_MAP.height) return null;
              const tile = getLakeTileType(mapX, mapY);
              const color = TILE_COLORS[tile] ?? '#1d4ed8';
              return (
                <div
                  key={`${mapX},${mapY}`}
                  className="absolute border border-black/10"
                  style={{
                    left: col * TILE_SIZE,
                    top: row * TILE_SIZE,
                    width: TILE_SIZE,
                    height: TILE_SIZE,
                    backgroundColor: color,
                    fontSize: TILE_EMOJI[tile] ? 18 : undefined,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  {TILE_EMOJI[tile]}
                </div>
              );
            })
          )}

          {/* Player */}
          {(() => {
            const px = (playerPosition.x - camX) * TILE_SIZE;
            const py = (playerPosition.y - camY) * TILE_SIZE;
            if (px < 0 || py < 0 || px >= visibleW * TILE_SIZE || py >= visibleH * TILE_SIZE) return null;
            return (
              <div
                className="absolute flex items-center justify-center z-20 transition-all duration-200 rounded-full"
                style={{
                  left: px + 2,
                  top: py + 2,
                  width: TILE_SIZE - 4,
                  height: TILE_SIZE - 4,
                  backgroundColor: '#3b82f6',
                  border: '2px solid #f59e0b',
                  fontSize: 18,
                  boxShadow: '0 0 12px rgba(59, 130, 246, 0.6)',
                }}
              >
                🧙
              </div>
            );
          })()}

          {/* Enemies */}
          {enemies.map((enemy) => {
            if (enemy.defeated) return null;
            const ex = (enemy.position.x - camX) * TILE_SIZE;
            const ey = (enemy.position.y - camY) * TILE_SIZE;
            if (ex < -TILE_SIZE || ey < -TILE_SIZE || ex >= visibleW * TILE_SIZE || ey >= visibleH * TILE_SIZE) return null;
            const def = ENEMIES[enemy.enemyId];
            return (
              <div
                key={enemy.instanceId}
                className="absolute flex items-center justify-center z-10 rounded-full cursor-pointer transition-all hover:scale-110"
                style={{
                  left: ex + 2,
                  top: ey + 2,
                  width: TILE_SIZE - 4,
                  height: TILE_SIZE - 4,
                  backgroundColor: enemy.isBoss ? '#be185d' : def?.color ?? '#dc2626',
                  border: `2px solid ${enemy.isBoss ? '#f9a8d4' : '#fca5a5'}`,
                  fontSize: 16,
                  boxShadow: enemy.isBoss ? '0 0 16px rgba(190, 24, 93, 0.5)' : '0 0 8px rgba(220, 38, 38, 0.4)',
                }}
                onClick={() => tryMove(enemy.position.x - playerPosition.x, enemy.position.y - playerPosition.y)}
                title={`${enemy.isBoss ? '⚡ BOSS: ' : ''}${def?.name ?? enemy.enemyId} Lv.${enemy.level}`}
              >
                {def?.emoji ?? '👾'}
              </div>
            );
          })}
        </div>
      </div>

      {/* Mobile D-pad */}
      <div className="absolute bottom-4 right-4 grid grid-cols-3 gap-1 md:hidden">
        <div />
        <DPadBtn label="↑" onClick={() => tryMove(0, -1)} />
        <div />
        <DPadBtn label="←" onClick={() => tryMove(-1, 0)} />
        <DPadBtn label="↓" onClick={() => tryMove(0, 1)} />
        <DPadBtn label="→" onClick={() => tryMove(1, 0)} />
      </div>

      {/* Legend */}
      <div className="absolute bottom-4 left-4 text-xs text-gray-500">
        <div>WASD / Arrows to move</div>
        <div>Walk into enemies to fight</div>
        <div className="text-red-400">Enter fortress → boss in 3 steps</div>
      </div>
    </div>
  );
}

function DPadBtn({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button
      onTouchStart={(e) => { e.preventDefault(); onClick(); }}
      onClick={onClick}
      className="w-10 h-10 bg-gray-700/80 hover:bg-gray-600 text-white font-bold text-sm rounded-lg border border-gray-600 transition-all active:scale-90 active:bg-gray-500"
    >
      {label}
    </button>
  );
}
