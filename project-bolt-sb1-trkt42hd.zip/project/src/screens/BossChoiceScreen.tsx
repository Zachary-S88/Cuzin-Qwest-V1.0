import React, { useState } from 'react';
import { useGame } from '../contexts/GameContext';
import { CHARACTERS } from '../game/characters';
import type { CharacterId } from '../game/types';

const RESCUABLE: CharacterId[] = ['davy', 'granty', 'whyWhy'];

export default function BossChoiceScreen() {
  const { dispatch } = useGame();
  const [selected, setSelected] = useState<CharacterId | null>(null);
  const [confirmed, setConfirmed] = useState(false);

  if (confirmed && selected) {
    return (
      <div
        className="fixed inset-0 flex flex-col items-center justify-center gap-6 p-6"
        style={{ background: 'radial-gradient(ellipse, #1d4ed8 0%, #0a1628 80%)' }}
      >
        <div className="text-7xl animate-bounce">{CHARACTERS[selected].emoji}</div>
        <h1 className="text-white font-black text-3xl text-center" style={{ fontFamily: 'Nunito, sans-serif' }}>
          {CHARACTERS[selected].name} is rescued!
        </h1>
        <p className="text-blue-300 text-sm text-center max-w-xs">
          But the others were taken by Shelly and Kevin as they fled... There's more Qwest to come!
        </p>
        <button
          onClick={() => dispatch({ type: 'CHOOSE_RESCUE', characterId: selected })}
          className="px-8 py-4 font-black text-white text-lg rounded-2xl transition-all active:scale-95 shadow-2xl"
          style={{
            background: `linear-gradient(135deg, ${CHARACTERS[selected].color}, ${CHARACTERS[selected].secondaryColor})`,
            boxShadow: `0 8px 32px ${CHARACTERS[selected].color}55`,
          }}
        >
          Continue to Hub →
        </button>
      </div>
    );
  }

  return (
    <div
      className="fixed inset-0 overflow-y-auto"
      style={{ background: 'linear-gradient(180deg, #0f172a 0%, #1e3a5f 100%)' }}
    >
      <div className="max-w-lg mx-auto px-4 py-8">
        <div className="text-center mb-6">
          <div className="text-4xl mb-2">⚡</div>
          <h1 className="text-white font-black text-2xl" style={{ fontFamily: 'Nunito, sans-serif' }}>
            Choose Who to Rescue!
          </h1>
          <p className="text-gray-400 text-sm mt-2">
            Shelly and Kevin are fleeing with the other Cuzins. You can only reach one before they escape!
          </p>
        </div>

        <div className="space-y-4">
          {RESCUABLE.map((id) => {
            const def = CHARACTERS[id];
            const isSelected = selected === id;
            return (
              <button
                key={id}
                onClick={() => setSelected(id)}
                className={`w-full p-4 rounded-2xl text-left transition-all duration-200 active:scale-98 border-2 ${
                  isSelected ? 'border-yellow-400 scale-102 shadow-xl' : 'border-gray-700 hover:border-gray-500'
                }`}
                style={{ backgroundColor: isSelected ? `${def.color}22` : '#1f2937' }}
              >
                <div className="flex items-center gap-4">
                  <div
                    className="w-16 h-16 rounded-full flex items-center justify-center text-4xl shrink-0 border-2"
                    style={{ backgroundColor: def.color, borderColor: def.secondaryColor, boxShadow: `0 0 20px ${def.color}44` }}
                  >
                    {def.emoji}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-white font-black text-lg">{def.name}</div>
                    <div className="text-gray-400 text-xs italic mb-2">{def.tagline}</div>
                    <div className="grid grid-cols-5 gap-1">
                      {[
                        { label: 'HP', val: def.baseStats.maxHp, color: '#22c55e' },
                        { label: 'ATK', val: def.baseStats.attack, color: '#ef4444' },
                        { label: 'DEF', val: def.baseStats.defense, color: '#3b82f6' },
                        { label: 'SPD', val: def.baseStats.speed, color: '#f59e0b' },
                        { label: 'SPC', val: def.baseStats.special, color: '#a855f7' },
                      ].map(({ label, val, color }) => (
                        <div key={label} className="bg-gray-900 rounded text-center py-1">
                          <div className="font-black text-xs" style={{ color }}>{val}</div>
                          <div className="text-gray-500" style={{ fontSize: 8 }}>{label}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                  {isSelected && <div className="text-yellow-400 text-xl">✓</div>}
                </div>

                <div className="mt-3 space-y-1 text-xs">
                  <div className="text-gray-400">
                    <span className="text-gray-300 font-bold">Weapon:</span> {def.weapon.name} — {def.weapon.description.slice(0, 60)}...
                  </div>
                  <div className="text-gray-400">
                    <span className="text-gray-300 font-bold">Active:</span> {def.active.name} — {def.active.description.slice(0, 60)}...
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        <button
          disabled={!selected}
          onClick={() => setConfirmed(true)}
          className={`w-full mt-6 py-4 rounded-2xl font-black text-lg transition-all active:scale-95 ${
            selected
              ? 'text-white shadow-xl hover:scale-102'
              : 'bg-gray-800 text-gray-500 cursor-not-allowed'
          }`}
          style={
            selected
              ? {
                  background: `linear-gradient(135deg, ${CHARACTERS[selected].color}, ${CHARACTERS[selected].secondaryColor})`,
                  boxShadow: `0 6px 24px ${CHARACTERS[selected].color}44`,
                }
              : undefined
          }
        >
          {selected ? `Rescue ${CHARACTERS[selected].name}! →` : 'Select a Cuzin above'}
        </button>
      </div>
    </div>
  );
}
