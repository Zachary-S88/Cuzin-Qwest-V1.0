import React, { useState } from 'react';
import { useGame } from '../contexts/GameContext';
import { CHARACTERS } from '../game/characters';
import { getEffectiveStats } from '../game/levelSystem';
import { Shield, Swords, Zap, Star, Heart } from 'lucide-react';

type HubTab = 'explore' | 'party' | 'quests';

export default function HubScreen() {
  const [tab, setTab] = useState<HubTab>('explore');

  return (
    <div
      className="fixed inset-0 overflow-hidden flex flex-col"
      style={{ background: 'linear-gradient(180deg, #4ade80 0%, #22c55e 20%, #166534 60%, #14532d 100%)' }}
    >
      {/* Sky */}
      <div className="absolute top-0 left-0 right-0 h-40" style={{ background: 'linear-gradient(180deg, #bfdbfe 0%, #93c5fd 60%, transparent 100%)' }} />

      {/* Grammie's House scene */}
      <div className="relative flex items-end justify-center" style={{ height: 180 }}>
        {/* House */}
        <div className="relative">
          <div className="w-48 h-32 bg-amber-800 rounded-t-xl border-b-4 border-amber-900 flex items-end justify-center pb-2">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-8">
              <div className="w-0 h-0" style={{ borderLeft: '64px solid transparent', borderRight: '64px solid transparent', borderBottom: '48px solid #7c2d12' }} />
            </div>
            {/* Windows */}
            <div className="flex gap-4 mb-4">
              <div className="w-10 h-8 bg-yellow-200/60 rounded border-2 border-yellow-400/40 flex items-center justify-center text-sm">🌞</div>
              <div className="w-10 h-8 bg-yellow-200/60 rounded border-2 border-yellow-400/40 flex items-center justify-center text-sm">🌞</div>
            </div>
          </div>
          {/* Door */}
          <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-10 h-14 bg-amber-900 rounded-t-full border-2 border-amber-950 flex items-center justify-center text-xl">
            🚪
          </div>
        </div>
        {/* Trees */}
        <div className="absolute left-8 bottom-0 text-5xl select-none">🌲</div>
        <div className="absolute right-12 bottom-0 text-4xl select-none">🌳</div>
        <div className="absolute left-24 bottom-0 text-3xl select-none">🌿</div>
        {/* Sign */}
        <div className="absolute right-4 bottom-8 bg-amber-800 px-3 py-1 rounded border-2 border-amber-900">
          <div className="text-amber-100 font-black text-xs">Grammie's House</div>
        </div>
      </div>

      {/* Main panel */}
      <div className="flex-1 bg-gray-900/95 backdrop-blur-sm rounded-t-3xl overflow-hidden flex flex-col">
        {/* Tabs */}
        <div className="flex border-b border-gray-700">
          {(['explore', 'party', 'quests'] as HubTab[]).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`flex-1 py-3 font-bold text-sm capitalize transition-all ${tab === t ? 'text-blue-400 border-b-2 border-blue-400' : 'text-gray-500 hover:text-gray-300'}`}
            >
              {t === 'explore' ? '🗺 Explore' : t === 'party' ? '👥 Party' : '📋 Quests'}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          {tab === 'explore' && <ExploreTab />}
          {tab === 'party' && <PartyTab />}
          {tab === 'quests' && <QuestsTab />}
        </div>
      </div>
    </div>
  );
}

function ExploreTab() {
  const { state, dispatch } = useGame();
  const lakeEnemiesLeft = state.explorationState.enemies.filter((e) => !e.defeated && !e.isBoss).length;

  return (
    <div className="space-y-3">
      <div className="bg-gray-800 rounded-xl p-4">
        <div className="text-white font-black text-base mb-1">🗺 Cuzin Planet — Lake Region</div>
        <div className="text-gray-400 text-sm">
          Zachy must cross the lake and reach the Relative Fortress to rescue the kidnapped Cuzins.
        </div>
        <div className="mt-2 text-sm">
          <span className="text-yellow-400 font-bold">{lakeEnemiesLeft} enemies</span>
          <span className="text-gray-500"> remaining before fortress</span>
        </div>
        {state.storyFlags.bossDefeated && (
          <div className="mt-2 text-green-400 font-bold text-sm">✅ Boss Defeated!</div>
        )}
      </div>

      <button
        onClick={() => dispatch({ type: 'NAVIGATE', screen: 'exploration' })}
        className="w-full py-4 rounded-xl font-black text-white text-lg transition-all active:scale-95 shadow-lg hover:scale-105"
        style={{ background: 'linear-gradient(135deg, #1d4ed8, #2563eb)', boxShadow: '0 6px 20px rgba(37, 99, 235, 0.3)' }}
      >
        🌊 Head to the Lake
      </button>

      {!state.storyFlags.bossDefeated && (
        <button
          onClick={() =>
            dispatch({ type: 'START_COMBAT', enemyIds: ['shelly', 'kevin'], enemyLevels: [5, 5], environment: 'fortress', isBoss: true })
          }
          className="w-full py-3 rounded-xl font-black text-white text-sm transition-all active:scale-95"
          style={{ background: 'linear-gradient(135deg, #dc2626, #b91c1c)' }}
        >
          ⚡ Challenge the Fortress (Boss Fight)
        </button>
      )}

      {state.storyFlags.bossDefeated && state.storyFlags.rescuedCuzin && (
        <div className="bg-green-900/30 border border-green-700/50 rounded-xl p-3">
          <div className="text-green-400 font-bold text-sm">
            ✅ Rescued: {CHARACTERS[state.storyFlags.rescuedCuzin].name}!
          </div>
          <div className="text-gray-400 text-xs mt-1">More adventure areas coming soon!</div>
        </div>
      )}
    </div>
  );
}

function PartyTab() {
  const { state } = useGame();
  const party = state.party;

  return (
    <div className="space-y-3">
      <div className="text-gray-400 text-xs font-bold uppercase tracking-wider">Active Party</div>
      {party.map((pm) => {
        const def = CHARACTERS[pm.characterId];
        const stats = getEffectiveStats(pm);
        return (
          <div key={pm.characterId} className="bg-gray-800 rounded-xl p-4 border border-gray-700/50">
            <div className="flex items-start gap-3">
              <div
                className="w-14 h-14 rounded-full flex items-center justify-center text-3xl border-2 shrink-0"
                style={{ backgroundColor: def.color, borderColor: def.secondaryColor }}
              >
                {def.emoji}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-baseline gap-2">
                  <span className="text-white font-black text-base">{def.name}</span>
                  <span className="text-yellow-400 text-xs font-bold">Lv. {pm.level}</span>
                </div>
                <div className="text-gray-400 text-xs italic">{def.tagline}</div>
                <div className="mt-2 flex items-center gap-1">
                  <div className="flex-1 h-1.5 bg-gray-700 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full bg-green-500"
                      style={{ width: `${(pm.currentHp / stats.maxHp) * 100}%` }}
                    />
                  </div>
                  <span className="text-xs text-gray-400">{pm.currentHp}/{stats.maxHp}</span>
                </div>
                {/* XP bar */}
                <div className="mt-1 flex items-center gap-1">
                  <div className="flex-1 h-1 bg-gray-700 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full bg-yellow-400"
                      style={{ width: `${(pm.xp / pm.xpToNext) * 100}%` }}
                    />
                  </div>
                  <span className="text-xs text-gray-500">{pm.xp}/{pm.xpToNext} XP</span>
                </div>
              </div>
            </div>
            <div className="mt-3 grid grid-cols-5 gap-1 text-xs">
              {[
                { icon: Heart, label: 'HP', val: stats.maxHp, color: '#22c55e' },
                { icon: Swords, label: 'ATK', val: stats.attack, color: '#ef4444' },
                { icon: Shield, label: 'DEF', val: stats.defense, color: '#3b82f6' },
                { icon: Zap, label: 'SPD', val: stats.speed, color: '#f59e0b' },
                { icon: Star, label: 'SPC', val: stats.special, color: '#a855f7' },
              ].map(({ icon: Icon, label, val, color }) => (
                <div key={label} className="flex flex-col items-center bg-gray-900 rounded-lg py-1.5">
                  <Icon size={10} style={{ color }} />
                  <span style={{ color }} className="font-black mt-0.5">{val}</span>
                  <span className="text-gray-500" style={{ fontSize: 9 }}>{label}</span>
                </div>
              ))}
            </div>
          </div>
        );
      })}
      {party.length < state.unlockedCharacters.length && (
        <div className="text-gray-600 text-sm text-center py-2">
          More Cuzins available — rescue them first!
        </div>
      )}
    </div>
  );
}

function QuestsTab() {
  const { state } = useGame();
  return (
    <div className="space-y-3">
      <div className="bg-gray-800 rounded-xl p-4 border border-yellow-700/30">
        <div className="flex items-start gap-3">
          <div className="text-2xl">📜</div>
          <div>
            <div className="text-yellow-400 font-bold text-sm">Main Quest: Rescue the Cuzins!</div>
            <div className="text-gray-400 text-xs mt-1">
              The Relatives have kidnapped your Cuzin friends and taken them to their fortress by the lake. Defeat them and bring everyone home!
            </div>
            <div className="mt-2 space-y-1">
              <QuestStep done={state.storyFlags.openingComplete} label="Complete the opening" />
              <QuestStep done={state.storyFlags.lakeEnemiesDefeated >= 3} label="Defeat 3 lake enemies" />
              <QuestStep done={state.storyFlags.bossDefeated} label="Defeat Shelly & Kevin" />
              <QuestStep done={state.storyFlags.rescuedCuzin !== null} label="Rescue a Cuzin" />
            </div>
          </div>
        </div>
      </div>
      <div className="text-center text-gray-600 text-xs py-4">More quests unlocked as you progress...</div>
    </div>
  );
}

function QuestStep({ done, label }: { done: boolean; label: string }) {
  return (
    <div className={`flex items-center gap-2 text-xs ${done ? 'text-green-400' : 'text-gray-500'}`}>
      <span>{done ? '✅' : '⬜'}</span>
      <span>{label}</span>
    </div>
  );
}
