import React, { useEffect, useRef, useState } from 'react';
import { useGame } from '../contexts/GameContext';
import { CHARACTERS } from '../game/characters';
import type { CharacterId } from '../game/types';

interface FloatingChar {
  id: CharacterId;
  x: number;
  y: number;
  vx: number;
  vy: number;
  rotation: number;
  vr: number;
  scale: number;
}

export default function TitleScreen() {
  const { state, dispatch } = useGame();
  const [floaters, setFloaters] = useState<FloatingChar[]>([]);
  const animRef = useRef<number>(0);
  const [pressedPlay, setPressedPlay] = useState(false);

  const unlocked = state.unlockedCharacters;

  useEffect(() => {
    const init: FloatingChar[] = unlocked.map((id) => {
      return {
        id,
        x: Math.random() * 80 + 10,
        y: Math.random() * 70 + 10,
        vx: (Math.random() - 0.5) * 0.3,
        vy: (Math.random() - 0.5) * 0.3,
        rotation: Math.random() * 360,
        vr: (Math.random() - 0.5) * 0.5,
        scale: 0.8 + Math.random() * 0.6,
      };
    });
    setFloaters(init);

    let last = performance.now();
    function tick(now: number) {
      const dt = now - last;
      last = now;
      setFloaters((prev) =>
        prev.map((f) => {
          const nx = f.x + f.vx * dt * 0.05;
          const ny = f.y + f.vy * dt * 0.05;
          let nvx = f.vx;
          let nvy = f.vy;
          if (nx < 5 || nx > 90) nvx = -nvx;
          if (ny < 5 || ny > 85) nvy = -nvy;
          return { ...f, x: nx, y: ny, vx: nvx, vy: nvy, rotation: f.rotation + f.vr };
        })
      );
      animRef.current = requestAnimationFrame(tick);
    }
    animRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animRef.current);
  }, [unlocked]);

  function handlePlay() {
    setPressedPlay(true);
    setTimeout(() => {
      if (state.storyFlags.openingComplete) {
        dispatch({ type: 'NAVIGATE', screen: 'hub' });
      } else {
        dispatch({ type: 'NAVIGATE', screen: 'opening' });
      }
    }, 600);
  }

  return (
    <div className="fixed inset-0 overflow-hidden" style={{ background: 'radial-gradient(ellipse at 50% 80%, #0f3460 0%, #0a1628 50%, #050d1a 100%)' }}>
      {/* Stars */}
      <div className="absolute inset-0">
        {Array.from({ length: 80 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-white"
            style={{
              width: Math.random() * 2 + 1,
              height: Math.random() * 2 + 1,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 70}%`,
              opacity: 0.3 + Math.random() * 0.7,
              animation: `twinkle ${2 + Math.random() * 3}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 3}s`,
            }}
          />
        ))}
      </div>

      {/* Lake reflection at bottom */}
      <div
        className="absolute bottom-0 left-0 right-0 h-1/3"
        style={{ background: 'linear-gradient(to top, rgba(59, 130, 246, 0.15), transparent)' }}
      />

      {/* Floating characters */}
      {floaters.map((f) => {
        const def = CHARACTERS[f.id];
        return (
          <div
            key={f.id}
            className="absolute pointer-events-none"
            style={{
              left: `${f.x}%`,
              top: `${f.y}%`,
              transform: `rotate(${f.rotation}deg) scale(${f.scale})`,
              transition: 'transform 0.1s',
            }}
          >
            <div
              className="w-16 h-16 rounded-full flex items-center justify-center text-3xl shadow-lg border-2"
              style={{ backgroundColor: def.color, borderColor: def.secondaryColor, boxShadow: `0 0 20px ${def.color}55` }}
            >
              {def.emoji}
            </div>
            <div className="text-center mt-1 font-bold text-white text-xs" style={{ textShadow: '0 1px 4px rgba(0,0,0,0.9)' }}>
              {def.name}
            </div>
          </div>
        );
      })}

      {/* Main title */}
      <div className="absolute inset-0 flex flex-col items-center justify-center gap-6">
        {/* Logo */}
        <div className="text-center relative">
          <div
            className="font-black leading-none tracking-tight select-none"
            style={{
              fontSize: 'clamp(48px, 12vw, 120px)',
              fontFamily: 'Nunito, sans-serif',
              background: 'linear-gradient(135deg, #f59e0b, #fde68a, #f59e0b)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              textShadow: 'none',
              filter: 'drop-shadow(0 4px 20px rgba(245, 158, 11, 0.4)) drop-shadow(0 0 40px rgba(245, 158, 11, 0.2))',
            }}
          >
            Cuzin Qwest
          </div>
          <div className="text-blue-300 font-bold text-sm tracking-widest uppercase mt-1" style={{ fontFamily: 'Nunito, sans-serif' }}>
            A Turn-Based RPG Adventure
          </div>
        </div>

        {/* Play button */}
        <button
          onClick={handlePlay}
          className={`relative overflow-hidden font-black text-xl px-12 py-4 rounded-2xl shadow-2xl transition-all duration-150 select-none ${
            pressedPlay ? 'scale-110 shadow-yellow-400/50' : 'hover:scale-105 active:scale-95'
          }`}
          style={{
            fontFamily: 'Nunito, sans-serif',
            background: pressedPlay
              ? 'linear-gradient(135deg, #f59e0b, #ef4444)'
              : 'linear-gradient(135deg, #3b82f6, #1d4ed8)',
            color: 'white',
            boxShadow: '0 8px 32px rgba(59, 130, 246, 0.4)',
          }}
        >
          <span className="relative z-10">
            {state.storyFlags.openingComplete ? '🌟 Continue' : '⚡ Play'}
          </span>
          {/* Shine effect */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-100%] hover:translate-x-[100%] transition-transform duration-700" />
        </button>

        {/* Unlocked cuzin count */}
        <div className="text-gray-500 text-sm">
          {unlocked.length === 1 ? 'Zachy awaits...' : `${unlocked.length} Cuzins unlocked!`}
        </div>
      </div>

      {/* Platform hint */}
      <div className="absolute bottom-4 left-0 right-0 text-center text-gray-600 text-xs">
        PC & Mobile · Press C+C for dev menu
      </div>
    </div>
  );
}
