import React, { useState } from 'react';
import { useGame } from '../contexts/GameContext';
import DialogBox from '../components/DialogBox';

const OPENING_LINES = [
  {
    speaker: 'Narrator',
    text: "Welcome to Cuzin Planet — a utopia where Cuzins of all shapes and sizes live in harmony, surrounded by nature, lakes, and cozy towns.",
    portrait: '📖',
    color: '#94a3b8',
  },
  {
    speaker: 'Narrator',
    text: "Our story begins at Grammie's House, the beloved gathering place for all Cuzins. It's a peaceful afternoon, and everyone is hanging out...",
    portrait: '🏠',
    color: '#94a3b8',
  },
  {
    speaker: 'Zachy',
    text: "Ah, another beautiful day on Cuzin Planet. Erm, actually — the weather forecast did mention some atmospheric anomalies today...",
    portrait: '🧙',
    color: '#3b82f6',
  },
  {
    speaker: 'Davy',
    text: "I guess, bro. [scrolls phone]",
    portrait: '🎹',
    color: '#92400e',
  },
  {
    speaker: 'Granty',
    text: "FRUIT SNACKS!!! Anyone want some fruit snacks? I got a whole bag right here!!",
    portrait: '🧦',
    color: '#15803d',
  },
  {
    speaker: 'Why Why',
    text: "Why. Why are you yelling. Why.",
    portrait: '😤',
    color: '#ca8a04',
  },
  {
    speaker: 'Meggie',
    text: "Oh WOW, look out the window! What is THAT thing?!",
    portrait: '🎾',
    color: '#c2410c',
  },
  {
    speaker: 'Narrator',
    text: "Outside the central window of Grammie's House, above the vast shimmering lake... a massive alien spaceship drifts silently through the sky.",
    portrait: '🛸',
    color: '#94a3b8',
  },
  {
    speaker: 'Zachy',
    text: "...Erm, actually, that would be a Class-7 Relative vessel. I've read about these! We need to investigate immediately!",
    portrait: '🧙',
    color: '#3b82f6',
  },
  {
    speaker: 'Narrator',
    text: "All the Cuzins sprint to the lake and pull out their kayaks! You grab a paddle and push off into the water...",
    portrait: '🚣',
    color: '#94a3b8',
  },
  {
    speaker: 'Narrator',
    text: "You paddle hard across the shimmering lake, the spaceship growing larger in the sky above. The others shout encouragement from their kayaks.",
    portrait: '🌊',
    color: '#94a3b8',
  },
  {
    speaker: 'Narrator',
    text: "Then... the ship stops. A deep mechanical hum fills the air. Blinding beams of light shoot downward!",
    portrait: '⚡',
    color: '#94a3b8',
  },
  {
    speaker: 'Zachy',
    text: "TRACTOR BEAMS! Everyone scatter!!",
    portrait: '🧙',
    color: '#3b82f6',
  },
  {
    speaker: 'Narrator',
    text: "One by one, the Cuzins are snatched into the sky. Davy, Granty, Why Why, Meggie — all gone in an instant!",
    portrait: '😱',
    color: '#94a3b8',
  },
  {
    speaker: 'Narrator',
    text: "Zachy dives into the water just in time. As the ship slowly moves away, he hears a voice echoing from inside it...",
    portrait: '📡',
    color: '#94a3b8',
  },
  {
    speaker: 'Unknown Voice',
    text: "Heh heh heh... Find us at the Relative Fortress to the east, little wizard... if you dare~",
    portrait: '👤',
    color: '#be185d',
  },
  {
    speaker: 'Zachy',
    text: "...*adjusts glasses* Erm, actually, that sounded like a CHALLENGE. And I ACCEPT. I'm coming for all of you, Relatives.",
    portrait: '🧙',
    color: '#3b82f6',
  },
  {
    speaker: 'Narrator',
    text: "Zachy paddles toward the fortress in the distance. The first Cuzin is on their own... but not for long. Cuzin Qwest begins!",
    portrait: '⭐',
    color: '#f59e0b',
  },
];

type SceneKey = 'grammiesHouse' | 'lakePaddle' | 'tractorBeam' | 'questBegins';

export default function OpeningScene() {
  const { dispatch } = useGame();
  const [lineIndex, setLineIndex] = useState(0);

  const sceneBackgrounds: Record<SceneKey, React.CSSProperties> = {
    grammiesHouse: {
      background: 'radial-gradient(ellipse at 50% 100%, #7c3aed22 0%, #0f172a 60%)',
    },
    lakePaddle: {
      background: 'linear-gradient(180deg, #0ea5e9 0%, #1d4ed8 40%, #1e3a5f 70%, #0f172a 100%)',
    },
    tractorBeam: {
      background: 'linear-gradient(180deg, #1a0533 0%, #0f172a 50%)',
    },
    questBegins: {
      background: 'linear-gradient(180deg, #0f172a 0%, #164e63 60%, #1e3a5f 100%)',
    },
  };

  const sceneRanges: Record<SceneKey, [number, number]> = {
    grammiesHouse: [0, 5],
    lakePaddle: [6, 10],
    tractorBeam: [11, 14],
    questBegins: [15, 17],
  };

  function getSceneForLine(i: number): SceneKey {
    for (const [key, [start, end]] of Object.entries(sceneRanges) as [SceneKey, [number, number]][]) {
      if (i >= start && i <= end) return key;
    }
    return 'questBegins';
  }

  const currentScene = getSceneForLine(lineIndex);
  const handleComplete = () => dispatch({ type: 'COMPLETE_OPENING' });

  return (
    <div className="fixed inset-0 overflow-hidden transition-all duration-1000" style={sceneBackgrounds[currentScene]}>
      {/* Scene illustration */}
      <SceneIllustration scene={currentScene} />

      {/* Dialog box - receives all lines, handles internally */}
      <DialogBox
        lines={OPENING_LINES}
        onComplete={handleComplete}
        onLineChange={setLineIndex}
      />

      {/* Skip button */}
      <button
        onClick={handleComplete}
        className="absolute top-4 right-4 px-4 py-2 bg-black/40 hover:bg-black/60 text-gray-400 hover:text-white text-sm rounded-lg border border-gray-700 transition-all backdrop-blur-sm"
      >
        Skip ▶▶
      </button>
    </div>
  );
}

function SceneIllustration({ scene }: { scene: SceneKey }) {
  if (scene === 'grammiesHouse') {
    return (
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="relative w-full max-w-lg h-64 mt-16">
          {/* House silhouette */}
          <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-64 h-40 bg-amber-900/40 rounded-t-2xl border border-amber-700/30" />
          <div className="absolute bottom-36 left-1/2 -translate-x-1/2 w-0 h-0" style={{ borderLeft: '72px solid transparent', borderRight: '72px solid transparent', borderBottom: '40px solid rgba(146, 64, 14, 0.5)' }} />
          {/* Window with warm light */}
          <div className="absolute bottom-12 left-1/2 -translate-x-1/2 w-16 h-16 bg-yellow-400/20 rounded border border-yellow-400/30 flex items-center justify-center text-3xl">
            🏠
          </div>
          {/* Cuzins inside */}
          <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-3 text-2xl">
            <span className="animate-bounce" style={{ animationDelay: '0s' }}>🧙</span>
            <span className="animate-bounce" style={{ animationDelay: '0.1s' }}>🎹</span>
            <span className="animate-bounce" style={{ animationDelay: '0.2s' }}>🧦</span>
            <span className="animate-bounce" style={{ animationDelay: '0.3s' }}>😤</span>
            <span className="animate-bounce" style={{ animationDelay: '0.4s' }}>🎾</span>
          </div>
        </div>
      </div>
    );
  }

  if (scene === 'lakePaddle') {
    return (
      <div className="absolute inset-0 flex items-end justify-center pb-48">
        {/* Lake */}
        <div className="absolute bottom-0 left-0 right-0 h-1/2 opacity-40" style={{ background: 'linear-gradient(to top, #1d4ed8, transparent)' }} />
        {/* Spaceship */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 text-5xl animate-pulse" style={{ filter: 'drop-shadow(0 0 20px #a78bfa)' }}>
          🛸
        </div>
        {/* Zachy kayaking */}
        <div className="flex gap-4 text-3xl mb-2">
          <span className="animate-pulse">🚣</span>
          <span style={{ animationDelay: '0.15s' }} className="animate-pulse opacity-70">🚣</span>
          <span style={{ animationDelay: '0.3s' }} className="animate-pulse opacity-50">🚣</span>
        </div>
      </div>
    );
  }

  if (scene === 'tractorBeam') {
    return (
      <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
        <div className="text-6xl animate-pulse" style={{ filter: 'drop-shadow(0 0 30px #a78bfa)' }}>🛸</div>
        <div className="flex gap-8 text-3xl">
          {['🎹','🧦','😤','🎾'].map((e, i) => (
            <span
              key={i}
              className="animate-bounce"
              style={{
                animationDelay: `${i * 0.2}s`,
                filter: 'drop-shadow(0 0 10px #a78bfa)',
              }}
            >
              {e}
            </span>
          ))}
        </div>
        {/* Tractor beam effect */}
        <div className="absolute inset-0 pointer-events-none" style={{ background: 'radial-gradient(ellipse at 50% 30%, rgba(167, 139, 250, 0.15) 0%, transparent 60%)' }} />
      </div>
    );
  }

  // questBegins
  return (
    <div className="absolute inset-0 flex items-center justify-center">
      <div className="text-center">
        <div className="text-7xl mb-4" style={{ filter: 'drop-shadow(0 0 20px #3b82f6)' }}>🧙</div>
        <div className="text-blue-300 font-black text-2xl" style={{ fontFamily: 'Nunito, sans-serif' }}>
          Cuzin Qwest Begins!
        </div>
        {/* Stars */}
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute text-yellow-400 animate-ping"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              fontSize: Math.random() * 12 + 8,
              animationDuration: `${1 + Math.random() * 2}s`,
              animationDelay: `${Math.random() * 1}s`,
            }}
          >
            ✦
          </div>
        ))}
      </div>
    </div>
  );
}
