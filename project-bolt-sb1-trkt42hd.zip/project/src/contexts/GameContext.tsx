import React, { createContext, useContext, useReducer } from 'react';
import type {
  GameState, GameScreen, CharacterId, EnemyId, CombatEnvironment,
  Difficulty, MeggieDemeanor, StatusEffectId,
} from '../game/types';
import { createPartyMember } from '../game/levelSystem';
import { initialExplorationState, getLakeTileType } from '../game/maps';
import {
  initCombat, advanceTurn, executeWeaponAttack, getReachableTiles,
  getAttackTargets, runEnemyTurn, checkCombatEnd, processStartOfTurn,
  updateUnit, getUnit, addLog,
  clearOldDamageNumbers, executeZachyOrb,
  executeMeggieFluteSOlo,
} from '../game/combatEngine';
import { removeStatus, addStatus } from '../game/statusEffects';

// ─── Initial State ────────────────────────────────────────────────────────────

function makeInitialState(): GameState {
  const sessionId = localStorage.getItem('cuzin_session') ?? (() => {
    const id = crypto.randomUUID();
    localStorage.setItem('cuzin_session', id);
    return id;
  })();

  return {
    screen: 'title',
    party: [createPartyMember('zachy')],
    activeCharacterId: 'zachy',
    unlockedCharacters: ['zachy'],
    storyFlags: {
      openingComplete: false,
      bossDefeated: false,
      rescuedCuzin: null,
      visitedHub: false,
      lakeEnemiesDefeated: 0,
    },
    explorationState: initialExplorationState(),
    combatState: null,
    difficulty: 'normal',
    sessionId,
    pendingCombat: null,
  };
}

// ─── Actions ──────────────────────────────────────────────────────────────────

type GameAction =
  | { type: 'NAVIGATE'; screen: GameScreen }
  | { type: 'COMPLETE_OPENING' }
  | { type: 'VISIT_HUB' }
  | { type: 'START_COMBAT'; enemyIds: EnemyId[]; enemyLevels: number[]; environment: CombatEnvironment; isBoss: boolean; triggerInstanceId?: string }
  | { type: 'COMBAT_SELECT_ACTION'; action: 'move' | 'attack' | 'ability' | 'special' | 'none' }
  | { type: 'COMBAT_MOVE'; targetX: number; targetY: number }
  | { type: 'COMBAT_ATTACK'; targetId: string }
  | { type: 'COMBAT_USE_ZACHY_ORB'; targetIds: string[]; statusId: StatusEffectId }
  | { type: 'COMBAT_USE_DAVY_YT'; }
  | { type: 'COMBAT_USE_GRANTY_FRUITSNACKS' }
  | { type: 'COMBAT_TOGGLE_CHUD' }
  | { type: 'COMBAT_USE_WHYWHY_WHY'; targetId: string }
  | { type: 'COMBAT_USE_MEGGIE_FLUTE' }
  | { type: 'COMBAT_SPECIAL_DODGE' }
  | { type: 'COMBAT_SPECIAL_DISENGAGE' }
  | { type: 'COMBAT_SPECIAL_HEAL' }
  | { type: 'COMBAT_SPECIAL_ROOT' }
  | { type: 'COMBAT_END_TURN' }
  | { type: 'COMBAT_ENEMY_TURN_DONE' }
  | { type: 'COMBAT_CLEAR_DAMAGE_NUMBERS' }
  | { type: 'COMBAT_STOP_SHAKE' }
  | { type: 'CHOOSE_RESCUE'; characterId: CharacterId }
  | { type: 'SELECT_MEGGIE_DEMEANOR'; demeanor: MeggieDemeanor }
  | { type: 'UNLOCK_CHARACTER'; characterId: CharacterId }
  | { type: 'LEVEL_UP_BOOST'; characterId: CharacterId; statKey: string }
  | { type: 'SET_DIFFICULTY'; difficulty: Difficulty }
  | { type: 'LOAD_SAVE'; state: GameState }
  | { type: 'MOVE_PLAYER'; x: number; y: number }
  | { type: 'DEFEAT_MAP_ENEMY'; instanceId: string };

// ─── Reducer ──────────────────────────────────────────────────────────────────

function reducer(state: GameState, action: GameAction): GameState {
  switch (action.type) {

    case 'NAVIGATE':
      return { ...state, screen: action.screen };

    case 'COMPLETE_OPENING':
      return {
        ...state,
        screen: 'exploration',
        storyFlags: { ...state.storyFlags, openingComplete: true },
      };

    case 'VISIT_HUB':
      return {
        ...state,
        screen: 'hub',
        storyFlags: { ...state.storyFlags, visitedHub: true },
      };

    case 'START_COMBAT': {
      const diffMult = state.difficulty === 'easy' ? 0.75 : state.difficulty === 'hard' ? 1.25 : 1;
      const scaledLevels = action.enemyLevels.map((l) => Math.max(1, Math.round(l * diffMult)));
      const partyForCombat = state.party.map((pm) => ({
        characterId: pm.characterId,
        level: pm.level,
        currentHp: pm.currentHp,
        bonusStats: pm.bonusStats as Record<string, number>,
      }));
      const cs = initCombat(partyForCombat, action.enemyIds, scaledLevels, action.environment, action.isBoss);
      return {
        ...state,
        screen: 'combat',
        combatState: cs,
        pendingCombat: {
          enemyIds: action.enemyIds,
          enemyLevels: action.enemyLevels,
          environment: action.environment,
          isBossFight: action.isBoss,
          triggerInstanceId: action.triggerInstanceId,
        },
      };
    }

    case 'COMBAT_SELECT_ACTION': {
      if (!state.combatState) return state;
      const cs = state.combatState;
      const activeUnit = cs.activeUnitId ? getUnit(cs, cs.activeUnitId) : null;
      if (!activeUnit) return state;

      let highlighted: typeof cs.highlightedTiles = [];
      let targets: typeof cs.targetTiles = [];

      if (action.action === 'move') {
        highlighted = getReachableTiles(activeUnit, cs);
      } else if (action.action === 'attack') {
        const attackTargets = getAttackTargets(activeUnit, cs);
        targets = attackTargets.map((u) => u.position);
      }

      return {
        ...state,
        combatState: {
          ...cs,
          selectedAction: action.action,
          highlightedTiles: highlighted,
          targetTiles: targets,
        },
      };
    }

    case 'COMBAT_MOVE': {
      if (!state.combatState) return state;
      let cs = state.combatState;
      const activeUnit = cs.activeUnitId ? getUnit(cs, cs.activeUnitId) : null;
      if (!activeUnit || activeUnit.actionsUsed.moved) return state;

      const updated = {
        ...activeUnit,
        position: { x: action.targetX, y: action.targetY },
        actionsUsed: { ...activeUnit.actionsUsed, moved: true },
      };
      cs = updateUnit(cs, updated);
      cs = addLog(cs, `${activeUnit.name} moves to (${action.targetX}, ${action.targetY}).`, 'move');
      return { ...state, combatState: { ...cs, selectedAction: 'none', highlightedTiles: [], targetTiles: [] } };
    }

    case 'COMBAT_ATTACK': {
      if (!state.combatState) return state;
      let cs = state.combatState;
      const activeUnit = cs.activeUnitId ? getUnit(cs, cs.activeUnitId) : null;
      if (!activeUnit || activeUnit.actionsUsed.attacked) return state;

      cs = executeWeaponAttack(activeUnit.unitId, action.targetId, cs);
      const postUnit = getUnit(cs, activeUnit.unitId)!;
      cs = updateUnit(cs, { ...postUnit, actionsUsed: { ...postUnit.actionsUsed, attacked: true } });
      cs = { ...cs, selectedAction: 'none', targetTiles: [], highlightedTiles: [], isShaking: true };

      const result = checkCombatEnd(cs);
      if (result === 'victory') {
        cs = { ...cs, phase: 'victory' };
      } else if (result === 'defeat') {
        cs = { ...cs, phase: 'defeat' };
      }
      return { ...state, combatState: cs };
    }

    case 'COMBAT_USE_ZACHY_ORB': {
      if (!state.combatState) return state;
      let cs = state.combatState;
      cs = executeZachyOrb(cs.activeUnitId!, action.targetIds, action.statusId, cs);
      const result = checkCombatEnd(cs);
      if (result === 'victory') cs = { ...cs, phase: 'victory' };
      else if (result === 'defeat') cs = { ...cs, phase: 'defeat' };
      return { ...state, combatState: { ...cs, selectedAction: 'none' } };
    }

    case 'COMBAT_USE_DAVY_YT': {
      if (!state.combatState) return state;
      let cs = state.combatState;
      const davy = getUnit(cs, cs.activeUnitId!)!;
      const turnsUntil = cs.turnCount + 2;
      let updated = addStatus(davy, 'invisible');
      updated = { ...updated, ytShortsUntilTurn: turnsUntil, actionsUsed: { ...updated.actionsUsed, ability: true } };
      cs = updateUnit(cs, updated);
      cs = addLog(cs, `Davy scrolls YT Shorts and goes Invisible!`, 'ability');
      return { ...state, combatState: { ...cs, selectedAction: 'none' } };
    }

    case 'COMBAT_USE_GRANTY_FRUITSNACKS': {
      if (!state.combatState) return state;
      let cs = state.combatState;
      const granty = getUnit(cs, cs.activeUnitId!)!;
      const updated = {
        ...granty,
        fruitSnacksActive: true,
        actionsUsed: { ...granty.actionsUsed, ability: true },
        combatBuffs: [
          ...granty.combatBuffs,
          { id: 'fruitSnacks', name: 'FRUIT SNACKS!!!', description: 'Speed doubled, +25% weapon accuracy and damage.', color: '#fbbf24', isBuff: true },
        ],
      };
      cs = updateUnit(cs, updated);
      cs = addLog(cs, `Granty eats FRUIT SNACKS!!! Speed and attacks massively boosted!`, 'ability');
      return { ...state, combatState: { ...cs, selectedAction: 'none' } };
    }

    case 'COMBAT_TOGGLE_CHUD': {
      if (!state.combatState) return state;
      let cs = state.combatState;
      const granty = getUnit(cs, cs.activeUnitId!)!;
      const newChud = !granty.chudActive;
      let updated = { ...granty, chudActive: newChud };
      if (newChud) {
        updated = addStatus(updated, 'recuperation') as typeof updated;
        cs = addLog(cs, `Granty activates CHUD STANCE! Cannot move but takes 50% less damage.`, 'ability');
      } else {
        updated = removeStatus(updated, 'recuperation') as typeof updated;
        cs = addLog(cs, `Granty deactivates Chud Stance.`, 'ability');
      }
      cs = updateUnit(cs, updated);
      return { ...state, combatState: { ...cs, selectedAction: 'none' } };
    }

    case 'COMBAT_USE_WHYWHY_WHY': {
      if (!state.combatState) return state;
      let cs = state.combatState;
      const whyWhy = getUnit(cs, cs.activeUnitId!)!;
      const target = getUnit(cs, action.targetId);
      if (!target) return state;
      const updatedTarget = addStatus(target, 'confused', 3);
      cs = updateUnit(cs, updatedTarget);
      const updatedWW = {
        ...whyWhy,
        actionsUsed: { ...whyWhy.actionsUsed, ability: true },
        combatBuffs: [
          ...whyWhy.combatBuffs.filter((b) => b.id !== 'whyShield'),
          { id: 'whyShield', name: '-25% Dmg Taken', description: 'Why Why takes 25% less damage until start of next turn.', color: '#fde68a', isBuff: true },
        ],
      };
      cs = updateUnit(cs, updatedWW);
      cs = addLog(cs, `Why? ${target.name} is Confused! Why Why activates his shield!`, 'ability');
      return { ...state, combatState: { ...cs, selectedAction: 'none' } };
    }

    case 'COMBAT_USE_MEGGIE_FLUTE': {
      if (!state.combatState) return state;
      const cs = executeMeggieFluteSOlo(state.combatState.activeUnitId!, state.combatState);
      return { ...state, combatState: { ...cs, selectedAction: 'none' } };
    }

    case 'COMBAT_SPECIAL_DODGE': {
      if (!state.combatState) return state;
      let cs = state.combatState;
      const unit = getUnit(cs, cs.activeUnitId!)!;
      const withDodge = {
        ...unit,
        actionsUsed: { ...unit.actionsUsed, ability: true },
        combatBuffs: [
          ...unit.combatBuffs.filter((b) => b.id !== 'dodge'),
          { id: 'dodge', name: 'Dodging', description: 'Weapon attacks against you are at 60% accuracy until your next turn.', color: '#60a5fa', isBuff: true },
        ],
      };
      cs = updateUnit(cs, withDodge);
      cs = addLog(cs, `${unit.name} enters a defensive stance! (Dodge)`, 'system');
      return { ...state, combatState: { ...cs, selectedAction: 'none' } };
    }

    case 'COMBAT_SPECIAL_DISENGAGE': {
      if (!state.combatState) return state;
      let cs = state.combatState;
      const unit = getUnit(cs, cs.activeUnitId!)!;
      const updated = {
        ...unit,
        actionsUsed: { ...unit.actionsUsed, ability: true },
        combatBuffs: [
          ...unit.combatBuffs.filter((b) => b.id !== 'disengage'),
          { id: 'disengage', name: 'Disengaged', description: 'No opportunity attacks until start of your next turn.', color: '#86efac', isBuff: true },
        ],
      };
      cs = updateUnit(cs, updated);
      cs = addLog(cs, `${unit.name} disengages!`, 'system');
      return { ...state, combatState: { ...cs, selectedAction: 'none' } };
    }

    case 'COMBAT_SPECIAL_HEAL': {
      if (!state.combatState) return state;
      let cs = state.combatState;
      const unit = getUnit(cs, cs.activeUnitId!)!;
      // Try to reduce a status effect
      const timedEffect = unit.statusEffects.find((e) => e.turnsRemaining !== null);
      let updated = { ...unit, actionsUsed: { ...unit.actionsUsed, ability: true } };
      if (timedEffect) {
        updated = {
          ...updated,
          statusEffects: updated.statusEffects.map((e) =>
            e.id === timedEffect.id && e.turnsRemaining !== null
              ? { ...e, turnsRemaining: Math.max(0, e.turnsRemaining - 1), healCount: e.healCount + 1 }
              : e
          ).filter((e) => e.turnsRemaining === null || e.turnsRemaining > 0),
        };
        cs = addLog(cs, `${unit.name} attempts to heal the ${timedEffect.id} condition!`, 'system');
      } else {
        const healEffect = unit.statusEffects.find((e) => e.turnsRemaining === null);
        if (healEffect) {
          updated = {
            ...updated,
            statusEffects: updated.statusEffects.map((e) =>
              e.id === healEffect.id ? { ...e, healCount: e.healCount + 1 } : e
            ).filter((e) => e.healCount < 3),
          };
          cs = addLog(cs, `${unit.name} works on curing ${healEffect.id}!`, 'system');
        } else {
          cs = addLog(cs, `${unit.name} has no status conditions to heal!`, 'system');
        }
      }
      cs = updateUnit(cs, updated);
      return { ...state, combatState: { ...cs, selectedAction: 'none' } };
    }

    case 'COMBAT_SPECIAL_ROOT': {
      if (!state.combatState) return state;
      let cs = state.combatState;
      const unit = getUnit(cs, cs.activeUnitId!)!;
      const updated = {
        ...unit,
        actionsUsed: { ...unit.actionsUsed, moved: true, ability: true },
        combatBuffs: [
          ...unit.combatBuffs.filter((b) => b.id !== 'rootInPlace'),
          { id: 'rootInPlace', name: 'Rooted', description: '+50% weapon damage and +25% ability damage this turn.', color: '#d97706', isBuff: true },
        ],
      };
      cs = updateUnit(cs, updated);
      cs = addLog(cs, `${unit.name} roots in place for power!`, 'system');
      return { ...state, combatState: { ...cs, selectedAction: 'none' } };
    }

    case 'COMBAT_END_TURN': {
      if (!state.combatState) return state;
      let cs = advanceTurn(state.combatState);
      if (cs.activeUnitId) {
        cs = processStartOfTurn(cs.activeUnitId, cs);
      }
      const result = checkCombatEnd(cs);
      if (result === 'victory') cs = { ...cs, phase: 'victory' };
      else if (result === 'defeat') cs = { ...cs, phase: 'defeat' };
      return { ...state, combatState: cs };
    }

    case 'COMBAT_ENEMY_TURN_DONE': {
      if (!state.combatState) return state;
      let cs = runEnemyTurn(state.combatState.activeUnitId!, state.combatState);
      const result = checkCombatEnd(cs);
      if (result === 'victory') {
        cs = { ...cs, phase: 'victory' };
        return { ...state, combatState: cs };
      }
      if (result === 'defeat') {
        cs = { ...cs, phase: 'defeat' };
        return { ...state, combatState: cs };
      }
      cs = advanceTurn(cs);
      if (cs.activeUnitId) cs = processStartOfTurn(cs.activeUnitId, cs);
      const result2 = checkCombatEnd(cs);
      if (result2 === 'victory') cs = { ...cs, phase: 'victory' };
      else if (result2 === 'defeat') cs = { ...cs, phase: 'defeat' };
      return { ...state, combatState: cs };
    }

    case 'COMBAT_CLEAR_DAMAGE_NUMBERS': {
      if (!state.combatState) return state;
      return { ...state, combatState: clearOldDamageNumbers(state.combatState) };
    }

    case 'COMBAT_STOP_SHAKE': {
      if (!state.combatState) return state;
      return { ...state, combatState: { ...state.combatState, isShaking: false } };
    }

    case 'CHOOSE_RESCUE': {
      const newMember = createPartyMember(action.characterId);
      return {
        ...state,
        screen: 'hub',
        party: [...state.party, newMember],
        unlockedCharacters: [...new Set([...state.unlockedCharacters, action.characterId])],
        storyFlags: {
          ...state.storyFlags,
          bossDefeated: true,
          rescuedCuzin: action.characterId,
        },
        combatState: null,
      };
    }

    case 'SELECT_MEGGIE_DEMEANOR': {
      if (!state.combatState) return state;
      const active = state.combatState.activeUnitId;
      if (!active) return state;
      const unit = getUnit(state.combatState, active);
      if (!unit) return state;
      const updated = { ...unit, demeanor: action.demeanor };
      return { ...state, combatState: updateUnit(state.combatState, updated) };
    }

    case 'UNLOCK_CHARACTER': {
      if (state.unlockedCharacters.includes(action.characterId)) return state;
      const newMember = createPartyMember(action.characterId);
      return {
        ...state,
        party: [...state.party, newMember],
        unlockedCharacters: [...state.unlockedCharacters, action.characterId],
      };
    }

    case 'LEVEL_UP_BOOST': {
      return {
        ...state,
        party: state.party.map((pm) => {
          if (pm.characterId !== action.characterId) return pm;
          return {
            ...pm,
            bonusStats: {
              ...pm.bonusStats,
              [action.statKey]: ((pm.bonusStats as Record<string, number>)[action.statKey] ?? 0) + 5,
            },
          };
        }),
      };
    }

    case 'SET_DIFFICULTY':
      return { ...state, difficulty: action.difficulty };

    case 'LOAD_SAVE':
      return action.state;

    case 'MOVE_PLAYER': {
      const tile = getLakeTileType(action.x, action.y);
      const onFortress = tile === 'fortress';
      const prevOnFortress = getLakeTileType(state.explorationState.playerPosition.x, state.explorationState.playerPosition.y) === 'fortress';
      const newSteps = onFortress && !prevOnFortress
        ? state.explorationState.fortressStepsTaken + 1
        : state.explorationState.fortressStepsTaken;
      return {
        ...state,
        explorationState: {
          ...state.explorationState,
          playerPosition: { x: action.x, y: action.y },
          fortressStepsTaken: newSteps,
        },
      };
    }

    case 'DEFEAT_MAP_ENEMY': {
      const es = state.explorationState;
      return {
        ...state,
        combatState: null,
        screen: 'exploration',
        explorationState: {
          ...es,
          enemies: es.enemies.map((e) =>
            e.instanceId === action.instanceId ? { ...e, defeated: true } : e
          ),
        },
        storyFlags: {
          ...state.storyFlags,
          lakeEnemiesDefeated: state.storyFlags.lakeEnemiesDefeated + 1,
        },
      };
    }

    default:
      return state;
  }
}

// ─── Context ──────────────────────────────────────────────────────────────────

interface GameContextValue {
  state: GameState;
  dispatch: React.Dispatch<GameAction>;
}

const GameContext = createContext<GameContextValue | null>(null);

export function GameProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, undefined, makeInitialState);

  return (
    <GameContext.Provider value={{ state, dispatch }}>
      {children}
    </GameContext.Provider>
  );
}

// eslint-disable-next-line react-refresh/only-export-components
export function useGame() {
  const ctx = useContext(GameContext);
  if (!ctx) throw new Error('useGame must be used inside GameProvider');
  return ctx;
}
