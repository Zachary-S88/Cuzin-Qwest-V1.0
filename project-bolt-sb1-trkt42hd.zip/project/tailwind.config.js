/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        game: ['Nunito', 'sans-serif'],
      },
      animation: {
        shake: 'shake 0.4s ease-in-out',
        'float-damage': 'float-damage 1.8s ease-out forwards',
        'float-char': 'float-char 3s ease-in-out infinite',
        'pulse-ring': 'pulse-ring 1.2s ease-in-out infinite',
        twinkle: 'twinkle 2.5s ease-in-out infinite',
      },
      keyframes: {
        shake: {
          '0%, 100%': { transform: 'translate(0, 0) rotate(0deg)' },
          '10%': { transform: 'translate(-4px, -2px) rotate(-0.5deg)' },
          '20%': { transform: 'translate(4px, 2px) rotate(0.5deg)' },
          '30%': { transform: 'translate(-4px, 2px) rotate(0deg)' },
          '40%': { transform: 'translate(4px, -2px) rotate(0.5deg)' },
          '50%': { transform: 'translate(-3px, -1px) rotate(-0.5deg)' },
          '60%': { transform: 'translate(3px, 1px) rotate(0deg)' },
          '70%': { transform: 'translate(-2px, 2px) rotate(-0.25deg)' },
          '80%': { transform: 'translate(2px, -1px) rotate(0.25deg)' },
          '90%': { transform: 'translate(-1px, 0) rotate(0deg)' },
        },
        'float-damage': {
          '0%': { opacity: '1', transform: 'translateX(-50%) translateY(0) scale(1)' },
          '20%': { transform: 'translateX(-50%) translateY(-12px) scale(1.3)' },
          '100%': { opacity: '0', transform: 'translateX(-50%) translateY(-52px) scale(0.7)' },
        },
        'float-char': {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-8px)' },
        },
        'pulse-ring': {
          '0%, 100%': { transform: 'scale(1)', opacity: '1' },
          '50%': { transform: 'scale(1.12)', opacity: '0.7' },
        },
        twinkle: {
          '0%, 100%': { opacity: '0.3', transform: 'scale(1)' },
          '50%': { opacity: '1', transform: 'scale(1.3)' },
        },
      },
      scale: {
        '98': '0.98',
        '102': '1.02',
      },
    },
  },
  plugins: [],
};
