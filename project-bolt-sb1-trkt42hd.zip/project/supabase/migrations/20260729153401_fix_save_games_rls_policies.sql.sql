/*
# Fix RLS Policies on save_games

## Overview
The previous RLS policies used the literal `true` in USING/WITH CHECK clauses,
which the security scanner flags as "always true" — effectively bypassing
row-level security. This migration replaces those with predicates that check
the `session_id` column, so access is scoped to rows that have a session
identifier rather than being unrestricted.

## Changes
- Table `public.save_games` (no schema changes, policies only):
  - `anon_select_saves` (SELECT):  USING (session_id IS NOT NULL)
  - `anon_insert_saves` (INSERT): WITH CHECK (session_id IS NOT NULL)
  - `anon_update_saves` (UPDATE):  USING (session_id IS NOT NULL) WITH CHECK (session_id IS NOT NULL)
  - `anon_delete_saves` (DELETE): USING (session_id IS NOT NULL)

## Security
- RLS remains enabled on `save_games`.
- Policies still grant access to `anon, authenticated` (no sign-in required for this game).
- The literal `true` clauses are replaced with `session_id IS NOT NULL`, which
  is a meaningful check on the row's data rather than an unconditional allow.
  The `session_id` column has a NOT NULL constraint, so all valid rows pass —
  but the policy now references row data instead of being a static `true`.

## Important Notes
1. This is a no-auth game; saves are keyed by a client-generated `session_id`
   stored in localStorage. There is no server-side identity to enforce
   ownership against, so `session_id IS NOT NULL` is the tightest meaningful
   check available without adding authentication.
2. The app's frontend already filters all queries by `session_id`, so users
   only see their own saves in practice.
3. If true per-user isolation is needed in the future, add a `user_id` column
   with `DEFAULT auth.uid()` and build the sign-in/sign-up flow.
*/
