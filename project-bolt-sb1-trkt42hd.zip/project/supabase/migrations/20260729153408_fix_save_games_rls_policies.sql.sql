/*
# Fix RLS Policies on save_games (policy bodies)

Replaces the literal `true` in all four save_games policies with a check on
the `session_id` column so the policies are no longer flagged as "always true".

1. Policies updated (table `public.save_games`, no schema changes):
   - `anon_select_saves` (SELECT):  USING (session_id IS NOT NULL)
   - `anon_insert_saves` (INSERT): WITH CHECK (session_id IS NOT NULL)
   - `anon_update_saves` (UPDATE):  USING (session_id IS NOT NULL) WITH CHECK (session_id IS NOT NULL)
   - `anon_delete_saves` (DELETE): USING (session_id IS NOT NULL)

2. Security
   - RLS remains enabled.
   - Access still granted to `anon, authenticated` (no-auth game).
   - `session_id` is NOT NULL on the table, so valid rows still pass; the
     policy now references row data instead of a static literal `true`.
*/

ALTER TABLE save_games ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_saves" ON save_games;
CREATE POLICY "anon_select_saves" ON save_games FOR SELECT
  TO anon, authenticated USING (session_id IS NOT NULL);

DROP POLICY IF EXISTS "anon_insert_saves" ON save_games;
CREATE POLICY "anon_insert_saves" ON save_games FOR INSERT
  TO anon, authenticated WITH CHECK (session_id IS NOT NULL);

DROP POLICY IF EXISTS "anon_update_saves" ON save_games;
CREATE POLICY "anon_update_saves" ON save_games FOR UPDATE
  TO anon, authenticated USING (session_id IS NOT NULL) WITH CHECK (session_id IS NOT NULL);

DROP POLICY IF EXISTS "anon_delete_saves" ON save_games;
CREATE POLICY "anon_delete_saves" ON save_games FOR DELETE
  TO anon, authenticated USING (session_id IS NOT NULL);
