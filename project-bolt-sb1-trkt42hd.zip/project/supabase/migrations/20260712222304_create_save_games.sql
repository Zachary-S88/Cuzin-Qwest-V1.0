/*
# Cuzin Qwest - Save Games Table

## Overview
Stores save game data for the Cuzin Qwest RPG. No authentication required;
saves are identified by a client-generated session ID stored in localStorage.

## Tables
- `save_games`
  - `id` (uuid, primary key)
  - `session_id` (text) — anonymous client session UUID
  - `slot_number` (smallint) — save slot (1-3)
  - `save_data` (jsonb) — full serialized game state
  - `created_at` / `updated_at` (timestamps)

## Security
- RLS enabled; all policies grant anon + authenticated access (no sign-in required).
- Data is keyed by session_id — not a true security boundary, but appropriate for a local RPG game.
*/

CREATE TABLE IF NOT EXISTS save_games (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id text NOT NULL,
  slot_number smallint NOT NULL DEFAULT 1,
  save_data jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(session_id, slot_number)
);

ALTER TABLE save_games ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_saves" ON save_games;
CREATE POLICY "anon_select_saves" ON save_games FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_saves" ON save_games;
CREATE POLICY "anon_insert_saves" ON save_games FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_saves" ON save_games;
CREATE POLICY "anon_update_saves" ON save_games FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_saves" ON save_games;
CREATE POLICY "anon_delete_saves" ON save_games FOR DELETE
  TO anon, authenticated USING (true);
